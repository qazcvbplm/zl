var app = getApp();
let that;

Page({

  data: {
    load: true,
    text:""
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function (options) {
    that = this;
    this.findArticleDetail(options.id);
    that.setData({
      id: options.id
    })
  },

  //请求文章
  findArticleDetail: function (id) {
    that.showLoading()
    app.post('/ops/rich/text/find', { richTextId: id }, function (res) {
      if (res.data.code) {
        var reg = new RegExp("<img", "g")
        res.data.params.msg[0].text = res.data.params.msg[0].text.replace(reg, "<img width='100%'")
        that.setData({
          text: res.data.params.msg[0].text
        })
        that.hideLoading()
      } else {
        that.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  // 转发后显示的内容函数
  onShareAppMessage: function (res) {
    var that = this
    if (res.from === 'button') { }
    return {
      title: " 深度好文值得分享",
      path: '/pages/richText/richText?id=' + that.data.id,
    }
  },
})