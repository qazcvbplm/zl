var app = getApp();
var that;

Page({

  data: {
    floorName: '请选择该校楼栋',
    floors: [],
    floorId: '',
    schoolFloors: [],
    contactPerson: '',
    contactPhone: '',
    contactDoor: '',
    setDefault: false,
  },

  onLoad: function(options) {
    that = this
  },

  onShow: function() {
    that.findFloors();
    that.bianJiAddress()
  },

  //获取该校所有楼栋
  findFloors: function() {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    //获取楼栋地址
    app.post('/ops/floor/find', {
      page: 1,
      size:1000,
      schoolId: wx.getStorageSync("schoolId")
    }, function(res) {
      if (res.data.code) {
        for (let i = 0; i < res.data.params.list.length; i++) {
          that.data.schoolFloors.push(res.data.params.list[i].name);
        }
        that.setData({
          schoolFloors: that.data.schoolFloors,
          floors: res.data.params.list
        })
        wx.hideLoading()
      }else{
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //判断是否有默认地址或者是从编辑进入的
  bianJiAddress: function() {
    if (wx.getStorageSync("bianJiAddress")) {
      if (wx.getStorageSync("defaultAddress")) {
        if (wx.getStorageSync("defaultAddress").id == wx.getStorageSync("bianJiAddress").id) {
          that.setData({
            'setDefault': true
          })
        }
      }
      that.setData({
        contactPerson: wx.getStorageSync("bianJiAddress").name,
        contactPhone: wx.getStorageSync("bianJiAddress").phone,
        floorName: wx.getStorageSync("bianJiAddress").floorName,
        contactDoor: wx.getStorageSync("bianJiAddress").detail,
        floorId: wx.getStorageSync("bianJiAddress").floorId
      })
    }
  },

  //选择楼栋
  bindPickerChange: function(e) {
    that.setData({
      floorName: that.data.floors[e.detail.value].name,
      floorId: that.data.floors[e.detail.value].id
    })
  },

  //联系人
  contactPersonInput: function(e) {
    that.setData({
      contactPerson: e.detail.value
    })
  },

  //联系方式
  contactPhoneInput: function(e) {
      that.setData({
        contactPhone: e.detail.value
      })
  },

  //门牌号码
  contactDoorInput: function(e) {
    that.setData({
      contactDoor: e.detail.value
    })
  },

  //默认地址的选择
  setDefault: function(e) {
    that.setData({
      setDefault: e.detail.value
    })
  },

  //点击保存
  saveAddress: function() {
    if (that.data.contactPerson == "" || that.data.contactPhone.length != 11 || that.data.contactDoor == "" || that.data.floorName == "请选择该校楼栋") {
      wx.showToast({
        title: "未填完整信息",
        image: '/images/tanHao.png',
        duration: 2000,
        mask: true
      })
    } else if (wx.getStorageSync("bianJiAddress")) {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      app.post('/ops/address/update', {
        id: wx.getStorageSync("bianJiAddress").id,
        floorId: that.data.floorId,
        detail: that.data.contactDoor,
        name: that.data.contactPerson,
        phone: that.data.contactPhone,
      }, function(res) {
        wx.hideLoading()
        if (res.data.code) {
          if (wx.getStorageSync("bianJiAddress").id == wx.getStorageSync("defaultAddress").id) {
            if (that.data.setDefault) {
              wx.removeStorageSync('defaultAddress')
              wx.setStorageSync('defaultAddressId', wx.getStorageSync("bianJiAddress").id)
            } else {
              wx.removeStorageSync('defaultAddress')
            }
          } else {
            if (that.data.setDefault) {
              wx.removeStorageSync('defaultAddress')
              wx.setStorageSync('defaultAddressId', wx.getStorageSync("bianJiAddress").id)
            } else {}
          }
          wx.removeStorageSync('bianJiAddress')
          wx.navigateBack({
            delta: 1, 
          })
        }else{
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    } else {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      app.post('/ops/address/add', {
        name: that.data.contactPerson,
        phone: that.data.contactPhone,
        schoolId: wx.getStorageSync("schoolId"),
        floorId: that.data.floorId,
        detail: that.data.contactDoor
      }, function(res) {
        wx.hideLoading()
        if (res.data.code) {
          if (that.data.setDefault && wx.getStorageSync("defaultAddress")) {
            wx.removeStorageSync('defaultAddress')
            wx.setStorageSync('addressLength', true)
          } else if (that.data.setDefault && !wx.getStorageSync("defaultAddress")) {
            wx.setStorageSync('addressLength', true)
          } else {

          }
          wx.navigateBack({
            delta: 1, 
          })
        }else{
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    }
  },

  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})