var app = getApp();
var that;

Page({

  data: {
    load: true,
    bindPhone: false,
    selected: false,
    address: [],
    schoolName: '',
    addressId: '0'
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function(options) {
    that = this
    that.showLoading()
    if (options.type) {
      that.setData({
        selected: true
      })
    }
  },

  onShow: function() {
    if (!wx.getStorageSync("phone")) {
      this.setData({
        bindPhone: true
      })
      that.hideLoading()
    } else {
      if (wx.getStorageSync("bianJiAddress")) {
        wx.removeStorageSync('bianJiAddress')
      }
      if (wx.getStorageSync("defaultAddress")) {
        that.setData({
          addressId: wx.getStorageSync("defaultAddress").id
        })
      } else {
        that.setData({
          addressId: ''
        })
      }
      that.addFind()
    }
  },


  getPhoneNumber: function(e) {
    var that = this
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    wx.login({
      success: function(res) {
        app.post('/ops/user/getSessionKey', {
          code: res.code,
          schoolId: wx.getStorageSync("schoolId")
        }, function(res) {
          if (res.data.code) {
            if (e.detail.errMsg == "getPhoneNumber:ok") {
              app.post('/ops/user/decryptPhone', {
                decryptData: e.detail.encryptedData,
                sessionKey: res.data.params.map.sessionKey,
                ivData: e.detail.iv,
                openid: wx.getStorageSync("user").openId
              }, function(res) {
                if (res.data.code) {
                  that.setData({
                    bindPhone: false
                  })
                  that.addFind()
                  wx.hideLoading()
                  wx.setStorageSync("phone", true)
                } else {
                  if (res.data.msg == '手机号解密失败') {
                    wx.login({
                      success: function(res) {
                        app.post('/ops/user/getSessionKey', {
                          code: res.code,
                          schoolId: wx.getStorageSync("schoolId")
                        }, function(res) {
                          if (res.data.code) {
                            app.post('/ops/user/decryptPhone', {
                              decryptData: e.detail.encryptedData,
                              sessionKey: res.data.params.map.sessionKey,
                              ivData: e.detail.iv,
                              openid: wx.getStorageSync("user").openId
                            }, function(res) {
                              if (res.data.code) {
                                that.setData({
                                  bindPhone: false
                                })
                                that.addFind()
                                wx.hideLoading()
                                wx.setStorageSync("phone", true)
                              } else {
                                wx.showToast({
                                  title: res.data.msg,
                                  icon: 'none',
                                  duration: 2000,
                                  mask: true,
                                })
                              }
                            })
                          } else {
                            wx.showToast({
                              title: res.data.msg,
                              icon: 'none',
                              duration: 2000,
                              mask: true,
                            })
                          }
                        })
                      }
                    })
                  } else {
                    wx.showToast({
                      title: res.data.msg,
                      icon: 'none',
                      duration: 2000,
                      mask: true,
                    })
                  }
                }
              })
            } else {
              wx.showToast({
                title: '请点击允许',
                icon: 'none',
                duration: 2000,
                mask: true,
              })
            }
          } else {
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 2000,
              mask: true,
            })
          }
        })
      }
    })
  },

  //跳转填写地址界面
  addAddress: function(e) {
    wx.navigateTo({
      url: '/pages/mine/location/addContact/addContact',
    })
  },

  //查询收获地址
  addFind: function() {
    app.post('/ops/address/find', {
      openId: wx.getStorageSync("user").openId
    }, function(res) {
      if (res.data.code) {
        for (let i = 0; i < res.data.params.list.length; i++) {
          for (let j = 0; j < wx.getStorageSync("hoslist").length; j++) {
            if (res.data.params.list[i].schoolId == wx.getStorageSync("hoslist")[j].id) {
              res.data.params.list[i].schoolName = wx.getStorageSync("hoslist")[j].name
            }
          }
        }
        if (wx.getStorageSync("addressLength")) {
          wx.setStorageSync("defaultAddress", res.data.params.list[res.data.params.list.length - 1]);
          that.setData({
            addressId: res.data.params.list[res.data.params.list.length - 1].id
          })
          wx.removeStorageSync('addressLength')
        } else if (wx.getStorageSync("defaultAddressId")) {
          for (var i = 0; i < res.data.params.list.length; i++) {
            if (res.data.params.list[i].id == wx.getStorageSync("defaultAddressId")) {
              wx.setStorageSync("defaultAddress", res.data.params.list[i]);
            }
          }
          that.setData({
            addressId: wx.getStorageSync("defaultAddressId")
          })
          wx.removeStorageSync('defaultAddressId')
        }
        that.setData({
          address: res.data.params.list,
        })
        that.hideLoading()
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //删除地址
  delItem: function(e) {
    wx.showModal({
      title: '提示',
      content: '是否确认删除此地址',
      confirmText: '确认',
      confirmColor: '#3797ee',
      success: function(res) {
        if (res.confirm) {
          wx.showLoading({
            title: '加载中',
            mask: true
          })
          app.post('/ops/address/update', {
            id: that.data.address[e.currentTarget.dataset.index].id,
            isDelete: 1
          }, function(res) {
            wx.hideLoading()
            if (res.data.code) {
              if (that.data.address[e.currentTarget.dataset.index].id == wx.getStorageSync("defaultAddress").id) {
                wx.removeStorageSync("defaultAddress");
              }
              that.data.address.splice(e.currentTarget.dataset.index, 1)
              that.setData({
                address: that.data.address
              })
            } else {
              wx.showToast({
                title: res.data.msg,
                icon: 'none',
                duration: 2000,
                mask: true,
              })
            }
          })
        }
      }
    })
  },

  //编辑地址
  bianJi: function(e) {
    wx.setStorageSync('bianJiAddress', that.data.address[e.currentTarget.dataset.index])
    wx.navigateTo({
      url: '/pages/mine/location/addContact/addContact',
    })
  },

  //设为默认地址
  setDefault: function(e) {
    wx.setStorageSync("defaultAddress", that.data.address[e.currentTarget.dataset.index]);
    that.setData({
      addressId: that.data.address[e.currentTarget.dataset.index].id,
    })
    if (that.data.selected) {
      wx.navigateBack({
        delta: 1,
      })
    }
  },

  //转发后显示的内容
  onShareAppMessage: function() {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})