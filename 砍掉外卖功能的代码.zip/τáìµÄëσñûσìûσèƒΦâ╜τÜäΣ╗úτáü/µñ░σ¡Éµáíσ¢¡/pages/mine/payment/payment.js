var app = getApp();
var that;

Page({

  data: {
    load: true,
    btnloading: false,
    money: 0,
    source: 0,
    foodCoupon: 0,
    showdetail: false,
    bindPhone: false,
    chargeId: '',
    numbers: [],
    userCharges: []
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function(options) {
    that = this
  },

  onShow: function() {
    if (!wx.getStorageSync("phone")) {
      that.hideLoading()
      this.setData({
        bindPhone: true
      })
    } else {
      this.findRechage()
      this.findUserCharges()
      this.findUserMoney()
    }
  },

  getPhoneNumber: function(e) {
    var that = this
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    wx.login({
      success: function(res) {
        app.post('/ops/user/getSessionKey', {
          code: res.code,
          schoolId: wx.getStorageSync("schoolId")
        }, function(res) {
          if (res.data.code) {
            if (e.detail.errMsg == "getPhoneNumber:ok") {
              app.post('/ops/user/decryptPhone', {
                decryptData: e.detail.encryptedData,
                sessionKey: res.data.params.map.sessionKey,
                ivData: e.detail.iv,
                openid: wx.getStorageSync("user").openId
              }, function(res) {
                if (res.data.code) {
                  that.setData({
                    bindPhone: false
                  })
                  that.findRechage()
                  that.findUserCharges()
                  that.findUserMoney()
                  wx.hideLoading()
                  wx.setStorageSync("phone", true)
                } else {
                  if (res.data.msg == '手机号解密失败') {
                    wx.login({
                      success: function(res) {
                        app.post('/ops/user/getSessionKey', {
                          code: res.code,
                          schoolId: wx.getStorageSync("schoolId")
                        }, function(res) {
                          if (res.data.code) {
                            if (e.detail.errMsg == "getPhoneNumber:ok") {
                              app.post('/ops/user/decryptPhone', {
                                decryptData: e.detail.encryptedData,
                                sessionKey: res.data.params.map.sessionKey,
                                ivData: e.detail.iv,
                                openid: wx.getStorageSync("user").openId
                              }, function(res) {
                                if (res.data.code) {
                                  that.setData({
                                    bindPhone: false
                                  })
                                  that.findRechage()
                                  that.findUserCharges()
                                  that.findUserMoney()
                                  wx.hideLoading()
                                  wx.setStorageSync("phone", true)
                                } else {
                                  wx.showToast({
                                    title: res.data.msg,
                                    icon: 'none',
                                    duration: 2000,
                                    mask: true,
                                  })
                                }
                              })
                            } else {
                              wx.showToast({
                                title: '请点击允许',
                                icon: 'none',
                                duration: 2000,
                                mask: true,
                              })
                            }
                          } else {
                            wx.showToast({
                              title: res.data.msg,
                              icon: 'none',
                              duration: 2000,
                              mask: true,
                            })
                          }
                        })
                      }
                    })
                  } else {
                    wx.showToast({
                      title: res.data.msg,
                      icon: 'none',
                      duration: 2000,
                      mask: true,
                    })
                  }
                }
              })
            } else {
              wx.showToast({
                title: '请点击允许',
                icon: 'none',
                duration: 2000,
                mask: true,
              })
            }
          } else {
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 2000,
              mask: true,
            })
          }
        })
      }
    })
  },

  findUserMoney: function() {
    app.get('/ops/user/wx/get/bell', {
      openId: wx.getStorageSync("user").openId,
    }, function(res) {
      if (res.data.code) {
        that.setData({
          source: res.data.params.bell.source ? res.data.params.bell.source.toFixed(1) : 0,
          money: res.data.params.bell.money ? res.data.params.bell.money.toFixed(1) : 0,
          foodCoupon: res.data.params.bell.foodCoupon ? res.data.params.bell.foodCoupon.toFixed(1) : 0,
        })
        wx.setStorageSync('userMoney', res.data.params.bell.money ? res.data.params.bell.money.toFixed(1) : 0);
        wx.setStorageSync('foodCoupon', res.data.params.bell.foodCoupon ? res.data.params.bell.foodCoupon.toFixed(1) : 0);
        that.hideLoading()
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  findUserCharges: function() {
    app.post('/ops/user/findcharges', {
      openId: wx.getStorageSync("user").openId
    }, function(res) {
      if (res.data.code) {
        wx.hideLoading()
        that.setData({
          userCharges: res.data.params.msg
        })
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //查看充值额度
  findRechage: function() {
    app.post('/ops/charge/find', {

    }, function(res) {
      if (res.data.code) {
        for (let i = 0; i < res.data.params.list.length; i++) {
          res.data.params.list[i].act = false
        }
        that.setData({
          numbers: res.data.params.list
        })
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //选择充值额度
  getPay: function(e) {
    if (that.data.numbers[e.currentTarget.dataset.index].act == true) {
      that.data.numbers[e.currentTarget.dataset.index].act = false;
      that.setData({
        chargeId: ''
      })
    } else {
      for (var i = 0; i < that.data.numbers.length; i++) {
        that.data.numbers[i].act = false;
      }
      that.data.numbers[e.currentTarget.dataset.index].act = true;
      that.setData({
        chargeId: that.data.numbers[e.currentTarget.dataset.index].id
      })
    }
    that.setData({
      numbers: that.data.numbers
    })
  },

  saveNewAdres: function() {
    if (that.data.chargeId != '') {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      that.setData({
        btnloading: true
      })
      app.post('/ops/user/charges', {
        chargeId: that.data.chargeId,
      }, function(res) {
        if (res.data.code) {
          //成功
          wx.requestPayment({
            timeStamp: res.data.params.msg.time,
            nonceStr: res.data.params.msg.nonceStr,
            package: 'prepay_id=' + res.data.params.msg.prepay_id,
            signType: 'MD5',
            paySign: res.data.params.msg.paySign,
            success: function(res) {
              console.log(res)
              wx.hideLoading()
              wx.showToast({
                title: '支付成功',
                icon: '/images/success.png',
                duration: 2000,
                mask: true
              })
              that.findUserMoney()
              that.findUserCharges()
              that.setData({
                showdetail: false,
                btnloading: false,
              })
            },
            fail: function() {
              wx.hideLoading()
              wx.showToast({
                image: '/images/tanHao.png',
                title: '支付失败',
                duration: 2000,
                mask: true
              })
              that.setData({
                showdetail: false,
                btnloading: false,
              })
              // app.login()
            }
          })
        } else {
          that.setData({
            btnloading: false,
          })
          wx.hideLoading()
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    } else {
      wx.showToast({
        title: '未选择充值额度',
        image: '/images/tanHao.png',
        duration: 2000,
        mask: true
      })
    }
  },

  recharge: function() {
    for (var i = 0; i < that.data.numbers.length; i++) {
      that.data.numbers[i].act = false;
    }
    that.setData({
      numbers: that.data.numbers,
      showdetail: true,
      chargeId: ''
    })
  },
  close: function() {
    that.setData({
      showdetail: false,
    })
  },

  //转发后显示的内容
  onShareAppMessage: function() {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})