var app = getApp();
var that;

Page({

  data: {
    load: true,
    address: { schoolName: '请选择默认地址' },
    source: 0,
    tabs: [
      { title: '积分兑换', content: '内容一', active: true},
      { title: '兑换纪录', content: '内容二', active: false},
    ],
    tab: 0,
    isFollow: false,
    showdetail: false,
    showdetail2: false,
    exchangeGoods: [],
    exchangeRecords: [],
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function(options) {
    that = this
  },

  onShow: function() {
    that.showLoading()
    var query = {
      page: 1,
      size: 100000,
      schoolId: 1,
      isShow: 1
    }
    var query2 = {
      page: 1,
      size: 100000,
      appId: 1,
      openId: wx.getStorageSync("user").openId,
    }
    that.setData({
      query: query,
      query2: query2
    })
    that.findUserSource()
    that.initAddress();
    that.findShops(query, false)
  },

  findUserSource: function () {
    app.get('/ops/user/wx/get/bell', {
      openId: wx.getStorageSync("user").openId,
    }, function (res) {
      if (res.data.code) {
        that.setData({
          source: res.data.params.bell.source ? res.data.params.bell.source.toFixed(2) : 0,
        })
        that.hideLoading()
        wx.hideLoading()
      }else{
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  // 切换头部
  onClick: function (e) {
    for (var i = 0; i < that.data.tabs.length; i++) {
      that.data.tabs[i].active = false;
    }
    if (e.currentTarget.dataset.index == 1) {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      that.findOrders(that.data.query2,false)
    }
    that.data.tabs[e.currentTarget.dataset.index].active = true;
    that.setData({
      tabs: that.data.tabs,
      tab: e.currentTarget.dataset.index
    })
  },

  //请求所有积分商品
  findShops: function (query,bottom){
    //请求所有的物品
    app.post('/ops/source/product/find', query, function (res) {
      if (res.data.code) {
        //成功
        if (bottom == false) {
          that.setData({
            exchangeGoods: res.data.params.list,
          })
        } else {
          that.setData({
            exchangeGoods: that.data.exchangeGoods.concat(res.data.params.list)
          })
        }
      }else{
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //请求所有兑换纪录
  findOrders: function(query,bottom){
    //查询订单
    app.post('/ops/source/order/find', query, function (res) {
      if (res.data.code) {
        //成功
        for (var i in res.data.params.list) {
          res.data.params.list[i].createTime = res.data.params.list[i].createTime.substring(0, 19);
        }
        if (bottom == false) {
          that.setData({
            exchangeRecords: res.data.params.list,
          })
        } else {
          that.setData({
            exchangeRecords: that.data.exchangeRecords.concat(res.data.params.list),
          })
        }
        wx.hideLoading()
      }else{
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //缓存如果有默认地址拿出来用
  initAddress: function () {
    if (wx.getStorageSync("defaultAddress")) {
      //获取楼栋地址
      app.post('/ops/floor/find', {
        page: 1,
        size: 1000,
        schoolId: wx.getStorageSync("schoolId")
      }, function (res) {
        if (res.data.code) {
          var num = -1
          for (let i = 0; i < res.data.params.list.length; i++) {
            if (res.data.params.list[i].id == wx.getStorageSync("defaultAddress").floorId) {
              num = i
            }
          }
          if (num != -1) {
            that.setData({
              address: wx.getStorageSync("defaultAddress"),
              floorId: res.data.params.list[num].id,
            })
          } else {
            wx.showModal({
              title: '提示',
              content: '默认地址的信息已失效，请重新设置默认地址',
              showCancel: false,
              confirmColor: '#3797ee',
              confirmText: '前往设置',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateTo({
                    url: '/pages/mine/location/location?type=1',
                  })
                }
              }
            })
          }
        } else {
          wx.hideLoading()
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    } else {
      wx.hideLoading()
    }
  },

  // 跳转到我的界面的地址界面
  moreCusInfo: function () {
    wx.navigateTo({
      url: '/pages/mine/location/location?type=1',
    })
  },

  // 显示积分规则
  integralIule: function() {
    that.setData({
      showdetail: true,
    })
  },

  // 关闭showdetail
  close: function() {
    this.setData({
      showdetail: false,
      showdetail2: false,
      isFollow: false
    })
  },

  // 点击兑换
  exChange: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
      app.get('/ops/user/wx/check/gz', {
        openId: wx.getStorageSync("user").openId,
      }, function (res) {
        if (res.data.code) {
          wx.hideLoading()
          if (res.data.params.gz) {
            that.data.productId = that.data.exchangeGoods[e.currentTarget.dataset.index].id
            that.data.payPrice = that.data.exchangeGoods[e.currentTarget.dataset.index].price
            that.data.productImage = that.data.exchangeGoods[e.currentTarget.dataset.index].productImage
            that.data.productName = that.data.exchangeGoods[e.currentTarget.dataset.index].productName
            that.setData({
              showdetail2: true,
              payPrice: that.data.payPrice
            })
          } else {
            that.setData({
              isFollow: true,
            })
          }
        }else{
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
  },

  // 确认兑换
  takeShops: function () {
    if (that.data.address.schoolName == "请选择默认地址") {
      wx.showToast({
        title: "请选择默认地址",
        image: '/images/tanHao.png',
        duration: 2000,
        mask: true
      })
    }else{
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      app.post('/ops/source/order/add', {
        floorId: that.data.floorId,
        addressName: that.data.address.name,
        addressPhone: that.data.address.phone,
        addressDetail: that.data.address.schoolName + ',' + that.data.address.floorName + ',' + that.data.address.detail,
        id: that.data.productId,
        payPrice: that.data.payPrice,
        productImage: that.data.productImage,
        productName: that.data.productName,
        openId: wx.getStorageSync("user").openId,
        appId: 1,
        schoolId: wx.getStorageSync("schoolId")
      }, function (res) {
        if (res.data.code) {
          //成功
          wx.showModal({
            title: '提示',
            content: '下单成功，请等待管理员联系您',
            showCancel: false,
            confirmColor: '#3797ee',
            confirmText: '我已知晓',
            success: function (res) {
              if (res.confirm) {
                var source = that.data.source - that.data.payPrice
                that.setData({
                  showdetail: false,
                  showdetail2: false,
                  source: source
                })
              }
            }
          })
          wx.hideLoading()
        } else {
          that.setData({
            showdetail: false,
            showdetail2: false,
          })
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    }
  },
  
  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})