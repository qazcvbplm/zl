var app = getApp();
var that
Page({

  data: {
    swiperCurrent: 0,
    autoplay: false
  },

  onLoad: function (options) {
    that = this
    app.getWindow(this);
    var data = JSON.parse(options.data)
    that.setData({
      data: data,
    })
  },

  navToMallMine: function (e) {
    wx.navigateTo({
      url: '/pages/index/mall/mallMine/mallMine',
    })
  },
  
  // 轮播图切换动作函数
  swiperChange: function (e) {
    this.setData({
      swiperCurrent: e.detail.current
    })
  },

  fuzhi: function(){
    wx.setClipboardData({
      data: that.data.data.wxNumber,
      success(res) {
      }
    })
  },

  dandrer: function(){
    wx.showModal({
      title: '提示',
      content: '是否前往客服与帮助联系客服处理',
      showCancel: true,
      confirmColor: '#3797ee',
      confirmText: '确定',
      success: function (res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/mine/help/help',
          })
        }
      }
    })
  },

  shopPhone: function(){
    wx.makePhoneCall({
      phoneNumber: that.data.data.phone,
    })
  },

  onShareAppMessage: function (res) {
    return {
      title: that.data.data.title + "值得入手",
      path: '/pages/index/mall/details/details?data=' + JSON.stringify(that.data.data),
    }
  },

  onShow: function () {
    this.setData({
      autoplay: true
    })
  },

  onHide: function () {
    that.setData({
      autoplay: false
    })
  },
})