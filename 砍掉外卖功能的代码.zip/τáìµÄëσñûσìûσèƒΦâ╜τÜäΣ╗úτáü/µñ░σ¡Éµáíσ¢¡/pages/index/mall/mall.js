var app = getApp();
var that

Page({

  data: {
    load: true,
    array: [{ name: '全部分类' }, { name: '数码配件' }, { name: '复习资料' }, { name: '运动乐器' }, { name: '代步工具' }, { name: '服装鞋帽' }, { name: '美妆护肤' },],
    arrayChoose: '全部分类',
    index: 0,
    schoolList: [{ id: 0, name: "全部高校" }],
    schools: ['全部高校'],
    schoolsChoose: '全部高校',
    index2: 0,
    goodList: [],
    loadText: "下滑试试",
    searchMall: ''
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  navToDetails: function (e) {
    wx.navigateTo({
      url: '/pages/index/mall/details/details?data=' + JSON.stringify(that.data.goodList[e.currentTarget.dataset.index]),
    })
  },
  navToMallMine: function (e) {
    wx.navigateTo({
      url: '/pages/index/mall/mallMine/mallMine',
    })
  },

  // 选择学校
  bindPickerChange: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    var schoolsChoose = that.data.schools[e.detail.value];
    this.setData({
      searchMall : ''
    })
    if (schoolsChoose != "全部高校" && that.data.arrayChoose != "全部分类") {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
        schoolId: that.data.schoolList[e.detail.value].id,
        category: that.data.array[that.data.index].name
      }
    } else if (schoolsChoose != "全部高校" && that.data.arrayChoose == "全部分类") {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
        schoolId: that.data.schoolList[e.detail.value].id
      }
    } else if (schoolsChoose == "全部高校" && that.data.arrayChoose == "全部分类") {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
      }
    } else {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
        category: that.data.array[that.data.index].name
      }
    }
    that.setData({
      query: query,
      schoolsChoose: schoolsChoose,
      index2: e.detail.value
    })
    that.findOrders(query, false)
  },

  // 切换头部
  onClick: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    this.setData({
      searchMall: ''
    })
    var arrayChoose = that.data.array[e.detail.key].name;
    if (that.data.schoolsChoose != "全部高校" && arrayChoose != "全部分类") {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
        schoolId: that.data.schoolList[that.data.index2].id,
        category: arrayChoose
      }
    } else if (that.data.schoolsChoose != "全部高校" && arrayChoose == "全部分类") {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
        schoolId: that.data.schoolList[that.data.index2].id
      }
    } else if (that.data.schoolsChoose == "全部高校" && arrayChoose == "全部分类") {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
      }
    } else {
      var query = {
        page: 1,
        size: 10,
        isShow: 1,
        category: arrayChoose
      }
    }
    that.setData({
      query: query,
      arrayChoose: arrayChoose,
      index: e.detail.key
    })
    that.findOrders(query, false)
  },

  onLoad: function (options) {
    that = this;
    that.showLoading()
    var query = {
      page: 1,
      size: 10,
      isShow: 1,
    }
    that.findOrders(query, false)
    that.setData({
      schoolList: [{ id: 0, name: "全部高校" }],
      schools: ['全部高校'],
      schoolsChoose: '全部高校',
      index2: 0,
      query: query,
    })
    wx.request({
      url: app.globalData.IP + '/ops/school/find', //仅为示例，并非真实的接口地址
      data: {
        page: 1,
        size: 100,
        orderBy: 'sort desc',
        queryType: 'wxuser',
      },
      dataType: 'json',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      success(res) {
        if (res.data.code) {
          //成功
          for (let i = 0; i < res.data.params.list.length; i++) {
            if (res.data.params.list[i].name == '椰子校园配送版（用户勿选）') {
              res.data.params.list.splice(i, 0)
            } else if (res.data.params.list[i].name == '椰子校园商户版（用户勿选）') {
              res.data.params.list.splice(i, 0)
            } else if (res.data.params.list[i].name == '椰子校园合伙人版（用户勿选）') {
              res.data.params.list.splice(i, 0)
            } else {
              that.data.schools.push(res.data.params.list[i].name);
              that.data.schoolList.push(res.data.params.list[i]);
            }
          }
          that.setData({
            schools: that.data.schools,
            schoolList: that.data.schoolList
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      }
    })
  },

  findOrders: function (query, bottom) {
    app.post('/ops/secondhand/find', query, function (res) {
      if (res.data.code) {
        //成功
        for (var i = 0; i < res.data.params.list.length; i++) {
          // res.data.params.list[i].nickName = decodeURI(res.data.params.list[i].nickName);
          res.data.params.list[i].image = res.data.params.list[i].image.split(",");
        }
        if (res.data.params.list.length == 10) {
          that.data.loadText = '下滑试试'
        } else {
          that.data.loadText = '到底了'
        }
        if (bottom == false) {
          that.setData({
            goodList: res.data.params.list,
            loadText: that.data.loadText,
          })
        } else {
          that.setData({
            goodList: that.data.goodList.concat(res.data.params.list),
            loadText: that.data.loadText,
          })
        }
        that.hideLoading()
        wx.hideLoading()
      } else {
        that.hideLoading()
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //标题
  searchMall: function (e) {
    this.data.searchMall = e.detail.value
  },

  //模糊搜索
  searchMallBtn: function () {
    if (this.data.searchMall == ''){
      wx.showToast({
        title: '请输入内容搜索',
        image: '/images/tanHao.png',
        duration: 2000,
        mask: true
      })
    }else{
      var query = this.data.query
      query.page = 1;
      query.title = this.data.searchMall
      this.setData({
        query: query
      })
      this.findOrders2(query, false)
    }
  },

  findOrders2: function (query, bottom) {
    app.post('/ops/secondhand/fuzzyFindSecondHand', query, function (res) {
      if (res.data.code) {
        //成功
        for (var i = 0; i < res.data.params.list.length; i++) {
          // res.data.params.list[i].nickName = decodeURI(res.data.params.list[i].nickName);
          res.data.params.list[i].image = res.data.params.list[i].image.split(",");
        }
        if (res.data.params.list.length == 10) {
          that.data.loadText = '下滑试试'
        } else {
          that.data.loadText = '到底了'
        }
        if (bottom == false) {
          that.setData({
            goodList: res.data.params.list,
            loadText: that.data.loadText,
          })
        } else {
          that.setData({
            goodList: that.data.goodList.concat(res.data.params.list),
            loadText: that.data.loadText,
          })
        }
        that.hideLoading()
        wx.hideLoading()
      } else {
        that.hideLoading()
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  onReachBottom: function () {
    if (that.data.loadText == "下滑试试") {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      var query = that.data.query
      query.page += 1;
      this.data.searchMall == "" ? that.findOrders(query, true) : that.findOrders2(query, true)
    }
  },

  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})