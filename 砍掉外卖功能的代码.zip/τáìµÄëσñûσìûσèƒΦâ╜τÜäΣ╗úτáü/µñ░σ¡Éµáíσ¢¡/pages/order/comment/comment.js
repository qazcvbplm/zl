var app = getApp();
var that;

Page({

  data: {
    load: true,
    getpspl1: '',
    getsjpl1: '',
    star: 0,
    starMap: [
      '非常差',
      '差',
      '一般',
      '好',
      '非常好',
    ],
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function(options) {
    that = this;
    that.setData({
      orderId: options.orderId,
      typ: options.typ
    })
    this.findOrder()
  },

  //查询订单
  findOrder: function() {
    that.showLoading()
    if (that.data.typ != '跑腿订单') {

    } else {
      app.post('/ops/runorders/find', {
        id: that.data.orderId
      }, function(res) {
        if (res.data.code) {
          //成功    
          let order = res.data.params.list[0];
          that.setData({
            order: order,
          })
          that.hideLoading()
        } else {
          that.hideLoading()
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    }
  },

  // 获取评论
  getpspl: function(e) {
    that.setData({
      getpspl1: e.detail.value
    })
  },

  //选择星星
  myStarChoose(e) {
    let star = parseInt(e.target.dataset.star) || 0;
    this.setData({
      star: star,
    });
  },

  // 确认评论
  reallyConment: function(e) {
    if (that.data.star == 0 || that.data.getpspl1 == "") {
      wx.showToast({
        title: "请填写完整",
        image: '/images/tanHao.png',
        duration: 2000,
        mask: true
      })
    } else {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      app.post('/ops/evaluate/add', {
        userId: wx.getStorageSync("user").openId,
        schoolId: wx.getStorageSync("schoolId"),
        orderid: that.data.order.id,
        core: that.data.star * 2,
        content: that.data.getpspl1,
        shopId: that.data.order.shopId,
      }, function(res) {
        if (res.data.code) {
          //成功
          wx.hideLoading()
          wx.showToast({
            title: '评论成功',
            image: '/images/success.png',
            duration: 2000,
            mask: true
          })
          wx.navigateBack({
            delta: 1, // 回退前 delta(默认为1) 页面
          })
        }else{
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    }
  },

  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})