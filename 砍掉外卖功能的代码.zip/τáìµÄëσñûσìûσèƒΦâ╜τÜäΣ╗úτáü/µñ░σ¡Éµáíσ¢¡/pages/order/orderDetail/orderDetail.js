var app = getApp();
var that;

Page({

  data: {
    load: true
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function(options) {
    that = this;
    that.setData({
      orderId: options.orderId,
      typ: options.typ
    })
    this.findOrders();
  },

  //查询订单
  findOrders: function() {
    that.showLoading()
    if (that.data.typ != '跑腿订单') {

    } else {
      app.post('/ops/runorders/find', {
        id: that.data.orderId
      }, function(res) {
        if (res.data.code) {
          //成功    
          let order = res.data.params.list[0];
          if (order.payment == '余额支付') {
            order.payment = '钱包支付'
          }
          order.createDate = order.createTime.substring(0, 10);
          order.payPrice = order.totalPrice.toFixed(2)
          that.setData({
            order: order,
          })
          that.hideLoading()
        } else {
          that.hideLoading()
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    }
  },

  //取消订单
  cancel: function() {
    var api = '/ops/runorders/cancel'
    wx.showModal({
      title: '提示',
      content: '是否确认取消订单',
      showCancel: true,
      confirmColor: '#3797ee',
      confirmText: '确认',
      success: function(res) {
        if (res.confirm) {
          wx.showLoading({
            title: '加载中',
            mask: true
          })
          app.post(api, {
            id: that.data.order.id
          }, function(res) {
            wx.hideLoading()
            if (res.data.code) {
              //成功
              wx.showToast({
                title: '退款成功',
                image: '/images/success.png',
                duration: 2000,
                mask: true
              })
              wx.navigateTo({
                url: "/pages/order/orderDetail/orderDetail?orderId=" + that.data.order.id + '&typ=' + that.data.typ
              })
            } else {
              wx.showToast({
                title: res.data.msg,
                icon: 'none',
                duration: 2000,
                mask: true,
              })
            }
          })
        }
      }
    })
  },

  //支付订单
  orderPay: function() {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    let api = '/ops/runorders/pay'
    app.post(api, {
      orderId: this.data.orderId,
      payment: '微信支付',
      formid: ''
    }, function(res) {
      if (res.data.code) {
        wx.hideLoading()
        let msg = res.data.params.msg;
        wx.requestPayment({
          timeStamp: msg.time,
          nonceStr: msg.nonceStr,
          package: 'prepay_id=' + msg.prepay_id,
          signType: 'MD5',
          paySign: msg.paySign,
          success: function(res) {
            if (that.data.typ == "跑腿订单"){
              wx.redirectTo({
                url: "/pages/order/orderSuccess/orderSuccess?orderId=" + that.data.orderId + '&typ=' + that.data.typ
              })
            }
          },
          fail: function() {
            wx.showToast({
              title: "支付失败",
              icon: 'none',
              duration: 2000,
              mask: true,
            })
          }
        })
      } else {
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //联系骑手
  senderPhone: function(e) {
    wx.makePhoneCall({
      phoneNumber: that.data.order.senderPhone,
    })
  },


  //转发后显示的内容
  onShareAppMessage: function() {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})