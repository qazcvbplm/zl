var that;
var app = getApp();

Page({

  data: {
    orderId:'',
    typ: '',
    showdetail: false
  },

  onLoad: function (options) {
    that = this
    that.setData({
      orderId: options.orderId,
      typ: options.typ,
    })

  },

  close2: function () {
    that.setData({
      showdetail: false
    })
  },


  toIndex: function(){
    wx.switchTab({
      url: '/pages/index/index'
    })
  },

  toOrder: function(){
    wx.navigateTo({
      url: "/pages/order/orderDetail/orderDetail?orderId=" + that.data.orderId + '&typ=' + that.data.typ
    })
  },

  onShow: function () {
    var that = this
  },

  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '快来和我一起享校园品质生活吧！！',
      path: '/pages/index/index',
    }
  },
})