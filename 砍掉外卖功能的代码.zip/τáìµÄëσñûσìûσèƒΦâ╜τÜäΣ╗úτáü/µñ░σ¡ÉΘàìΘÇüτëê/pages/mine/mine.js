var app = getApp();
var that;

Page({

  data: {
    startDate: '请选择开始时间',
    endDate: '请选择结束时间',
    orderNumber: 0,
    orderTakeNumber: 0,
    orderRunNumber: 0,
    complete: 0,
    noComplete: 0,
    sendPrice: 0,
    userMoney: 0,
    showdetail: false,
    showList: false,
    userList: [],
    txList: [],
    loadText: '',
    txDay: ''
  },

  onLoad: function (options) {
    that = this
    this.setData({
      phone: wx.getStorageSync("sender").phone
    })
  },

  onShow: function () {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    that.findUserMoney()
    that.setData({
      startDate: '请选择开始时间',
      endDate: '请选择结束时间',
    })
    var timestamp = Date.parse(new Date());
    timestamp = timestamp / 1000;
    var n = timestamp * 1000;
    var date = new Date(n);
    var Y = date.getFullYear();
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    that.setData({
      txDay: D,
    })
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    app.post2('/ops/sender/nocheck/senderstatistics', {
      senderId: wx.getStorageSync("sender").id,
      beginTime: Y + "-" + M + "-" + D + ' ' + '00:00:01',
      endTime: Y + "-" + M + "-" + D + ' ' + '23:59:59'
    }, function (res) {
      if (res.data.code) {
        //成功
        res.data.params.result.runTotal = res.data.params.result.runSuccess + res.data.params.result.runNosuccess;
        res.data.params.result.takeoutTotal = res.data.params.result.takeoutSuccess + res.data.params.result.takeoutNosuccess;
        res.data.params.result.runSuccess = res.data.params.result.runSuccess == null ? 0 : res.data.params.result.runSuccess;
        res.data.params.result.takeoutSuccess = res.data.params.result.takeoutSuccess == null ? 0 : res.data.params.result.takeoutSuccess;
        res.data.params.result.runNosuccess = res.data.params.result.runNosuccess == null ? 0 : res.data.params.result.runNosuccess;
        res.data.params.result.takeoutNosuccess = res.data.params.result.takeoutNosuccess == null ? 0 : res.data.params.result.takeoutNosuccess;
        res.data.params.result.totalPrice = res.data.params.result.run_price + res.data.params.result.takeout_Price;
        that.setData({
          orderNumber: res.data.params.result.takeoutTotal + res.data.params.result.runTotal,
          orderTakeNumber: res.data.params.result.takeoutTotal,
          orderRunNumber: res.data.params.result.runTotal,
          complete: res.data.params.result.runSuccess + res.data.params.result.takeoutSuccess,
          noComplete: res.data.params.result.runNosuccess + res.data.params.result.takeoutNosuccess,
          sendPrice: res.data.params.result.totalPrice
        })
        var query = {
          page: 1,
          size: 99,
          id: wx.getStorageSync("sender").id
        }
        that.findTx(query, false)
      } else {
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },


  findTx: function (query, bottom) {
    app.get('/ops/txlog/sender/find',
      query, function (res) {
        wx.hideLoading()
        if (res.data.code) {
          if (bottom == false) {
            if (res.data.params.list.length == 99) {
              that.data.loadText = '下滑试试'
            } else {
              that.data.loadText = '到底了'
            }
            for (var i in res.data.params.list) {
              res.data.params.list[i].createTime = res.data.params.list[i].createTime.substr(0, 10)
            }
            that.setData({
              txList: res.data.params.list,
              loadText: that.data.loadText,
            })
          } else if (bottom == true) {
            if (res.data.params.list.length == 99) {
              that.data.loadText = '下滑试试'
            } else {
              that.data.loadText = '到底了'
            }
            for (var i in res.data.params.list) {
              res.data.params.list[i].createTime = res.data.params.list[i].createTime.substr(0, 10)
            }
            that.setData({
              txList: that.data.txList.concat(res.data.params.list),
              loadText: that.data.loadText,
            })
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
  },

  //联系方式
  contactPhoneInput: function (e) {
    that.setData({
      phone: e.detail.value
    })
  },

  findUserMoney: function () {
    app.get('/ops/user/wx/get/bell', {
      openId: wx.getStorageSync("user").openId,
    }, function (res) {
      if (res.data.code) {
        wx.hideLoading()
        that.setData({
          userMoney: res.data.params.bell.money ? res.data.params.bell.money.toFixed(2) : 0,
        })
      }else{
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //关于选定时间函数
  bindDateChange: function (e) {
    this.setData({
      startDate: e.detail.value + ' ' + '00:00:01',
    })
  },

  //关于选定时间函数
  bindeDateChange: function (e) {
    that.setData({
      endDate: e.detail.value + ' ' + '23:59:59',
    })
  },

  recharge: function () {
    if ( this.data.userMoney < 1){
      wx.showToast({
        title: '提现金额必须大于1元',
        duration: 2000,
        mask: true,
        icon: 'none',
      })
    }else{
      that.setData({
        showdetail: true
      })
    }
    // else if (this.data.txDay == 7) {
    //   that.setData({
    //     showdetail: true
    //   })
    // } else if (this.data.txDay == 14) {
    //   that.setData({
    //     showdetail: true
    //   })
    // } else if (this.data.txDay == 21) {
    //   that.setData({
    //     showdetail: true
    //   })
    // } else if (this.data.txDay == 28) {
    //   that.setData({
    //     showdetail: true
    //   })
    // } else {
    //   wx.showToast({
    //     title: '提现日每个月：7、14、21、28号',
    //     duration: 2000,
    //     mask: true,
    //     icon: 'none',
    //   })
    // }
  },

  close: function () {
    this.setData({
      showdetail: false,
      showList: false
    })
  },

  trueMoney: function () {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    that.setData({
      userList: [],
    })
    app.post2('/ops/user/find', {
      page:1,
      size:100,
      phone: that.data.phone,
      schoolId: wx.getStorageSync("sender").schoolId,
    }, function (res) {
      wx.hideLoading()
      if (res.data.code) {
        if (res.data.params.total[0].total == 0) {
          that.setData({
            userList: [],
            showList: true
          })
        } else {
          that.data.userList = res.data.params.list
          that.setData({
            userList: that.data.userList,
            showList: true
          })
        }
      }else{
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  readyTi: function () {
    if (!that.data.showList) {
      wx.showToast({
        title: '请先输入号码查询',
        duration: 2000,
        image: '/images/tanHao.png',
        mask: true
      })
    } else {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      app.post2('/ops/txlog/txapply', {
        amount: that.data.userMoney,
        shopid: 0,
        senderid: wx.getStorageSync("sender").openId,
        dzOpenid: that.data.userList[0].openId,
      }, function (res) {
        if (res.data.code) {
          wx.showToast({
            title: '成功提交申请',
            duration: 2000,
            image: '/images/success.png',
            mask: true
          })
          that.setData({
            showdetail: false,
            showList: false
          })
          that.findUserMoney()
          var query = {
            page: 1,
            size: 99,
            id: wx.getStorageSync("sender").id
          }
          that.findTx(query, false)
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    }
  },

  findShuju: function () {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    app.post2('/ops/sender/nocheck/senderstatistics', {
      senderId: wx.getStorageSync("sender").id,
      beginTime: that.data.startDate,
      endTime: that.data.endDate
    }, function (res) {
      if (res.data.code) {
        //成功
        res.data.params.result.runTotal = res.data.params.result.runSuccess + res.data.params.result.runNosuccess;
        res.data.params.result.takeoutTotal = res.data.params.result.takeoutSuccess + res.data.params.result.takeoutNosuccess;
        res.data.params.result.runSuccess = res.data.params.result.runSuccess == null ? 0 : res.data.params.result.runSuccess;
        res.data.params.result.takeoutSuccess = res.data.params.result.takeoutSuccess == null ? 0 : res.data.params.result.takeoutSuccess;
        res.data.params.result.runNosuccess = res.data.params.result.runNosuccess == null ? 0 : res.data.params.result.runNosuccess;
        res.data.params.result.takeoutNosuccess = res.data.params.result.takeoutNosuccess == null ? 0 : res.data.params.result.takeoutNosuccess;
        res.data.params.result.totalPrice = res.data.params.result.run_price + res.data.params.result.takeout_Price;
        that.setData({
          orderNumber: res.data.params.result.takeoutTotal + res.data.params.result.runTotal,
          orderTakeNumber: res.data.params.result.takeoutTotal,
          orderRunNumber: res.data.params.result.runTotal,
          complete: res.data.params.result.runSuccess + res.data.params.result.takeoutSuccess,
          noComplete: res.data.params.result.runNosuccess + res.data.params.result.takeoutNosuccess,
          sendPrice: res.data.params.result.totalPrice
        })
        wx.hideLoading()
      } else {
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '椰子校园配送版，一起跟我来赚外快吧！',
      path: '/pages/index/index',
    }
  },
})