var app = getApp();
var that;

Page({

  data: {
    phone: '',
    telInput: '',
    showdetail: true,
    captchaLabel: '60秒后重新发送',
    seconds: 60,
    captchaDisabled: false,
    tis: false
  },

  onLoad: function (options) {
    that = this
  },

  //输入手机号的值
  phone: function (e) {
    that.setData({
      phone: e.detail.value
    })
  },

  //输入验证码的值
  telInput: function (e) {
    that.setData({
      telInput: e.detail.value
    })
  },

  //获取验证码
  captcha: function (e) {
    if (that.data.phone.length == 11) {
      wx.showLoading({
        title: '加载中',
        mask: true
      })
      app.post2('/ops/user/getcode', {
        phone: that.data.phone
      }, function (res) {
        if (res.data.code) {
          wx.hideLoading()
          that.setData({
            captchaDisabled: true,
            showdetail: false,
          });
          // 启动以1s为步长的倒计时
          that.data.interval = setInterval(() => {
            if (that.data.seconds <= 1) {
              that.data.captchaLabel = '重新发送';
              that.data.seconds = 60;
              that.setData({
                captchaDisabled: false
              });
            } else {
              that.data.captchaLabel = --that.data.seconds + '秒后重新发送';
              that.setData({
                captchaDisabled: true,
              });
            }
            that.setData({
              seconds: that.data.seconds,
              captchaLabel: that.data.captchaLabel
            });
          }, 1000);
          // 停止倒计时
          setTimeout(function () {
            clearInterval(that.data.interval);
          }, 60 * 1000);
        } else {
          wx.hideLoading()
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
    } else {
      wx.hideLoading()
      wx.showToast({
        title: '手机号输入有误',
        image: '/images/tanHao.png',
        duration: 2000,
        mask: true
      })
    }
  },

  //点击登录
  saveNewAdres: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    app.post2('/ops/user/bind', {
      wxId: wx.getStorageSync("user").id,
      phone: that.data.phone,
      codes: that.data.telInput
    }, function (res) {
      if (res.data.code) {
        wx.hideLoading()
        wx.setStorageSync('user', res.data.params.user);
        wx.redirectTo({
          url: '/pages/index/index',
        })
      } else {
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },

  close2: function () {
    that.setData({
      tis: false,
    })
  },

  close: function () {
    setTimeout(function () {
      clearInterval(that.data.interval);
    }, 0);
    that.setData({
      phone: '',
      telInput: '',
      showdetail: true,
      captchaLabel: '60秒后重新发送',
      seconds: 60,
      captchaDisabled: false,
    })
  },

  onShow: function () {
    if (!wx.getStorageSync("tis")) {
      wx.setStorageSync('tis', true);
      that.setData({
        tis: true,
      })
    }
  },
  
  onShareAppMessage: function () {
    return {
      title: '椰子校园配送版，一起跟我来赚外快吧！',
      path: '/pages/index/index',
    }
  },
})