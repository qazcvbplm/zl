var app = getApp();
var that;

Page({

  data: {
    tabs: [
      { title: '待接手', content: '内容一', active: true },
      { title: '已接手', content: '内容二', active: false },
      { title: '已完成', content: '内容三', active: false }
    ],
    tab: 0,
    orders: [],
    sender: [],
    takeNumbers: 0,
    load: true,
    loadText: '',
  },

  showLoading() {
    this.setData({
      load: true
    })
  },
  hideLoading() {
    this.setData({
      load: false
    })
  },

  onLoad: function (options) {
    that = this
    that.findSender() 
  },

  onShow: function () {
    wx.removeTabBarBadge({
      index: 1,
    })
  },

  // 切换头部
  onClick: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    that.setData({
      orders: []
    })
    var index = e.currentTarget.dataset.index
    for (var i = 0; i < that.data.tabs.length; i++) {
      that.data.tabs[i].active = false;
    }
    that.data.tabs[index].active = true;
    if (index == 0) {
      var query = that.data.query;
      query.page = 1;
      that.findOrderTakout(query, false)
    } else if (index == 1) {
      var query2 = that.data.query2;
      query2.page = 1;
      that.findOrderTakout(query2, false)
    } else {
      var query3 = that.data.query3;
      query3.page = 1;
      that.findOrderTakout(query3, false)
    }
    that.setData({
      tabs: that.data.tabs,
      tab: e.currentTarget.dataset.index
    })
  },

  //查询配送员结果
  findSender: function () {
    that.showLoading()
    if (wx.getStorageSync("sender")) {
      that.setData({
        sender: wx.getStorageSync("sender")
      })
      var query = {
        page: 1,
        size: 6,
        status: '待接手',
        senderId: wx.getStorageSync("sender").id
      }
      var query2 = {
        page: 1,
        size: 6,
        status: '配送员已接手',
        senderId: wx.getStorageSync("sender").id
      }
      var query3 = {
        page: 1,
        size: 6,
        status: '已完成',
        senderId: wx.getStorageSync("sender").id
      }
      that.setData({
        query: query,
        query2: query2,
        query3: query3
      })
      that.findOrderTakout(query, false)
      // setInterval(function () {
      //   //要延时执行的代码
      //   wx.getLocation({
      //     type: 'gcj02',
      //     success: function (res) {
      //       app.post('sender/location', { senderId: that.data.senderId, lng: res.longitude, lat: res.latitude }, function (res) {
      //         if (res.data.code) {

      //         }
      //       })
      //     }
      //   })
      // }, 30000)
    } else {
      wx.redirectTo({
        url: '/pages/bindUser/bindUser'
      })
    }
  },

  //查找待接手订单
  findOrderTakout: function (query, bottom) {
    app.post('/ops/sender/nocheck/findorderbyrun',
      query, function (res) {
        if (res.data.code) {
          //成功
          app.post('/ops/sender/nocheck/findorderbytakeout', { page: 1, size: 1, status: '商家已接手', senderId: that.data.sender.id }, function (res) {
            if (res.data.code) {
              //成功
              if (res.data.params.list.length == 1 && that.data.sender.takeoutFlag == 1) {
                wx.setTabBarBadge({
                  index: 0,
                  text: 'new'
                })
              }
            } else {
              wx.showToast({
                title: res.data.msg,
                icon: 'none',
                duration: 2000,
                mask: true,
              })
            }
          })
          for (var i in res.data.params.list) {
            res.data.params.list[i].payPrice = (res.data.params.list[i].totalPrice).toFixed(2);
            switch (res.data.params.list[i].status) {
              case "待付款":
                res.data.params.list[i].style = 2;
                break;
              case "待接手":
                res.data.params.list[i].style = 0;
                break;
              case "商家已接手":
                res.data.params.list[i].style = 0;
                break;
              case "配送员已接手":
                res.data.params.list[i].style = 0;
                break;
              case "已完成":
                res.data.params.list[i].style = 3;
                break;
              case "已取消":
                res.data.params.list[i].style = 4;
                break;
            }
          }
          if (bottom == false && that.data.sender.runFlag == 1) {
            if (res.data.params.list.length == 6) {
              that.data.loadText = '下滑试试'
            } else {
              that.data.loadText = '到底了'
            }
            that.setData({
              orders: res.data.params.list,
              loadText: that.data.loadText,
            })
          } else if (bottom == true && that.data.sender.runFlag == 1){
            if (res.data.params.list.length == 6) {
              that.data.loadText = '下滑试试'
            } else {
              that.data.loadText = '到底了'
            }
            that.setData({
              orders: that.data.orders.concat(res.data.params.list),
              loadText: that.data.loadText,
            })
          }
          that.hideLoading()
          wx.hideLoading()
        } else {
          that.hideLoading()
          wx.hideLoading()
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000,
            mask: true,
          })
        }
      })
  },

  //打电话给用户
  userPhone: function (e) {
    wx.makePhoneCall({
      phoneNumber: that.data.orders[e.target.dataset.index].addressPhone,
    })
  },

  //接手订单函数
  takeOrder: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    app.post('/ops/sender/nocheck/senderacceptrun', { senderId: that.data.sender.id, orderId: e.target.id }, function (res) {
      if (res.data.code) {
        //成功
        wx.hideLoading()
        wx.showToast({
          title: '接手成功',
          image: '/images/success.png',
          duration: 1000,
          mask: true
        })
        that.data.orders[e.target.dataset.index].status = '配送员已接手'
        that.data.orders.splice(e.target.dataset.index, 1);
        that.setData({
          orders: that.data.orders
        });
      } else {
        wx.hideLoading()
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 1000,
          mask: true,
        })
        that.data.orders.splice(e.target.dataset.index, 1);
        that.setData({
          orders: that.data.orders
        });
      }
    })
  },

  //完成订单
  finishOrder: function (e) {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    app.post('/ops/sender/nocheck/senderendrun', { orderId: e.target.id}, function (res) {
      if (res.data.code) {
        //成功
        wx.showToast({
          title: '跑腿成功',
          image: '/images/success.png',
          duration: 1000,
          mask: true
        })
        wx.hideLoading()
        that.data.orders[e.target.dataset.index].status = '已完成'
        that.data.orders.splice(e.target.dataset.index, 1);
        that.setData({
          orders: that.data.orders
        });
      }else{
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          mask: true,
        })
      }
    })
  },
  
  //转发后显示的内容
  onShareAppMessage: function () {
    return {
      title: '椰子校园配送版，一起跟我来赚外快吧！',
      path: '/pages/index/index',
    }
  },

  onPullDownRefresh: function () {
    wx.showLoading({
      title: '加载中',
      mask: true
    })
    if (that.data.tab == 0) {
      var query = that.data.query;
      query.page = 1;
      that.findOrderTakout(query, false)
      wx.stopPullDownRefresh();
    } else if (that.data.tab == 1) {
      var query2 = that.data.query2;
      query2.page = 1;
      that.findOrderTakout(query2, false)
      wx.stopPullDownRefresh();
    } else {
      var query3 = that.data.query3;
      query3.page = 1;
      that.findOrderTakout(query3, false)
      wx.stopPullDownRefresh();
    }
  },

  onReachBottom: function () {
    if (that.data.loadText != '到底了') {
      if (that.data.tab == 0) {
        wx.showLoading({
          title: '加载中',
          mask: true
        })
        var query = that.data.query;
        query.page += 1;
        that.findOrderTakout(query, true)
      } else if (that.data.tab == 1) {
        wx.showLoading({
          title: '加载中',
          mask: true
        })
        var query2 = that.data.query2;
        query2.page += 1;
        that.findOrderTakout(query2, true)
      } else {
        wx.showLoading({
          title: '加载中',
          mask: true
        })
        var query3 = that.data.query3;
        query3.page += 1;
        that.findOrderTakout(query3, true)
      }
    }
  },
})
