<template>
    <div style="height:none;width:100%">
        <div class="login-panel">
            <div class="flexr-center item-center">
                <img src="../../assets/logo.png" width="40px" height="40px" alt="">
                <div style="margin-left:5px;font-size:16px">椰子校园后台管理系统</div>
            </div>
            <el-form :model="data" status-icon  ref="ruleForm" label-position="top" class="demo-ruleForm" style="margin-top:20px">
                <el-form-item label="管理员账号" prop="age">
                    <el-input v-model.number="data.adminName" placeholder="输入管理员账号"></el-input>
                </el-form-item>
                <el-form-item label="管理员密码" prop="checkPass">
                    <el-input type="password" v-model="data.adminPwd" placeholder="输入管理员密码" autocomplete="off"></el-input>
                </el-form-item>
                <RadioGroup v-model="type">
                    <Radio label="学校负责人登陆"></Radio>
                    <Radio label="超级后台登陆"></Radio>
                </RadioGroup>
                <el-form-item>
                    <el-button type="primary" :loading="loading" style="width:100%;margin-top:20px" @click="submitForm()">登录</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
export default {
  data() {
    return {
      loading: false,
      type: '学校负责人登陆',
      data: {
        adminName: "",
        adminPwd: ""
      }
    };
  },
  methods: {
    //登录
    submitForm() {
      var that = this;
      if (this.data.adminName == "") {
        this.$message({
          showClose: true,
          type: "error",
          message: "请输入账号"
        });
      } else if (this.data.adminPwd == "") {
        this.$message({
          showClose: true,
          type: "error",
          message: "请输入密码"
        });
      }else {
        if(this.type == '学校负责人登陆'){
          this.loading = true;
          this.$http
            .post(
              this.com.NODE_API + "/ops/school/login",
              { loginName: this.data.adminName, loginPass: this.data.adminPwd ,type: 1},
              { emulateJSON: true ,}
            )
            .then(res => {
              this.loading = false;
              if (res.data.code) {
                this.$message({
                  showClose: true,
                  type: "success",
                  message: "登录成功"
                });
                sessionStorage.setItem("token", res.data.params.token);
                sessionStorage.setItem("schoolId", res.data.params.school.id);
                sessionStorage.setItem("schoolName", res.data.params.school.name);
                sessionStorage.setItem("loginName", this.data.adminName);
                sessionStorage.setItem("loginPass", this.data.adminPwd);
                sessionStorage.setItem("type", '学校负责人登陆');
                this.$router.push({ path: "/adminOverview" });
              } else {
                this.$message({
                  showClose: true,
                  type: "error",
                  message: "登录失败"
                });
              }
            }); 
        }else{
        this.loading = true;
        this.$http
          .post(
            this.com.NODE_API + "/ops/school/login",
            { loginName: this.data.adminName, loginPass: this.data.adminPwd,type: 2 },
            { emulateJSON: true ,}
          )
          .then(res => {
            this.loading = false;
            if (res.data.code) {
              this.$message({
                showClose: true,
                type: "success",
                message: "登录成功"
              });
                sessionStorage.setItem("surperId", res.data.params.admin.id);
                sessionStorage.setItem("surperName", this.data.adminName);
                sessionStorage.setItem("addSchoolList", res.data.params.admin.maxSchoolCount);
                sessionStorage.setItem("loginName", this.data.adminName);
                sessionStorage.setItem("loginPass", this.data.adminPwd);
                sessionStorage.setItem("token", res.data.params.token);
                sessionStorage.setItem("type", '超级后台登陆');
              this.$router.push({ path: "/adminOverview" });
            } else {
              this.$message({
                showClose: true,
                type: "error",
                message: "登录失败"
              });
            }
          });
        }
      }
    }
  }
};
</script>
