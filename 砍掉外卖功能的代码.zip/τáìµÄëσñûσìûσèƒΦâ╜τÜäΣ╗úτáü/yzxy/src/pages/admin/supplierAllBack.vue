<template>
</template>

<script>
    export default{
        data () {
            this.$router.push({
                path: "/sliderList"
            })
            return{

            }
        },
        methods: {}
    }
</script>