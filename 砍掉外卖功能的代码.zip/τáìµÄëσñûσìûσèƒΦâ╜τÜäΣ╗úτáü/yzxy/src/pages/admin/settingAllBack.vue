<template>
</template>

<script>
    export default{
        data () {
            this.$router.push({
                path: "/settingSchool"
            })
            return{

            }
        },
        methods: {}
    }
</script>