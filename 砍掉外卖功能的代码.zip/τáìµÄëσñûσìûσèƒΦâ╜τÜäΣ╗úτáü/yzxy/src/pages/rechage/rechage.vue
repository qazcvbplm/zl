<template>
  <div>
    <h2>充值列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="flexr-between margin-top-ershi">
      <ButtonGroup>
        <Button @click="newDialog = true">添加充值</Button>
      </ButtonGroup>
    </div>
    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="id" label="ID"></el-table-column>
      <el-table-column prop="full" label="充值额度"></el-table-column>
      <el-table-column prop="send" label="送的额度"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">删除</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page :total="total" :current="1" :page-size="1000" show-total/>
    </div>
    <el-dialog title="添加充值" :visible.sync="newDialog" width="300px" center>
      <Form :model="submitData" label-postion="top">
        <FormItem label="充值额度">
          <Input v-model="submitData.full" placeholder="请输入充值额度"></Input>
        </FormItem>
        <FormItem label="送的额度">
          <Input v-model="submitData.send" placeholder="请输入送的额度"></Input>
        </FormItem>
      </Form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="newDialog = false">取 消</el-button>
        <el-button type="primary" @click="newDialog = false,add()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      data2: {version:0},
      total: 0,
      getDataListquery: {},
      submitData: {
        full: "",
        send: ""
      },
      newDialog: false
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询总分类
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/charge/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.list.length;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    update(e, id) {
      if (e == 0) {
        this.$confirm(
          "此操作将永久删除该数据, 是否继续? 若误删请联系开发人员",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/charge/remove",
              { id: id },
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '删除成功'
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      }
    },

    add() {
      this.$http
        .post(this.com.NODE_API + "/ops/charge/add", this.submitData, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: '添加成功'
            });
            that.getDataList();
            this.submitData.full = "";
            this.submitData.send = "";
            this.newDialog = false;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
  }
};
</script>
