<template>
  <div>
    <h2>公告列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>
    <div class="flexr-between">
      <ButtonGroup>
        <Button @click="newDialog = true,submitData.title ='',submitData.content =''">添加公告</Button>
      </ButtonGroup>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="id" label="ID"></el-table-column>
      <el-table-column prop="title" label="公告标题"></el-table-column>
      <el-table-column prop="content" label="公告内容"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id,scope.row.title,scope.row.content)">删除</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id,scope.row.title,scope.row.content)">编辑</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
    <el-dialog title="保存公告" :visible.sync="newDialog" width="50%" center>
      <Form :model="submitData" label-postion="top">
        <FormItem label="公告标题">
          <Input v-model="submitData.title" placeholder="请输入公告标题"></Input>
        </FormItem>
        <FormItem label="公告内容">
          <Input v-model="submitData.content" placeholder="请输入公告内容"></Input>
        </FormItem>
      </Form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="newDialog = false">取 消</el-button>
        <el-button type="primary" @click="newDialog = false,add()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [{ key: "name", value: "", label: "输入公告标题" }],
      getDataListquery: {
        page: 1,
        size: 1000,
        schoolId: sessionStorage.getItem("schoolId")
      },
      submitData: {
        title: "",
        content:"",
        schoolId: sessionStorage.getItem("schoolId"),
      },
      newDialog: false
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询总分类
    getDataList() {
      this.$http
        .post(
          this.com.NODE_API + "/ops/notice/find",
          this.getDataListquery,
          {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          }
        )
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.list.length;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    update(e, id, title, content) {
      if (e == 0) {
        this.$confirm(
          "此操作将永久删除该数据, 是否继续? 若误删请联系开发人员",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/notice/update",
              { id: id, isDelete: 1 },
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '删除成功'
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      } else if (e == 1) {
        this.submitData.title = title
        this.submitData.content = content
        this.submitData.id = id
        this.newDialog = true;
      }
    },

    add() {
      if(this.submitData.id){
        this.$http
          .post(this.com.NODE_API + "/ops/notice/update", this.submitData, {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
          .then(res => {
            if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: '更新成功'
            });
              that.getDataList();
              this.submitData.title = '',
              this.submitData.content = '',
              this.newDialog = false
            } else {
              that.$message({
                showClose: true,
                type: "error",
                message: res.data.msg
              });
            }
          });
      }else{
        this.$http
          .post(this.com.NODE_API + "/ops/notice/add", this.submitData, {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
          .then(res => {
            if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: '添加成功'
            });
              that.getDataList();
              this.submitData.title = '',
              this.submitData.content = '',
              this.newDialog = false
            } else {
              that.$message({
                showClose: true,
                type: "error",
                message: res.data.msg
              });
            }
          });
      }
    },

    changePage(e) {
      this.getDataListquery.page = e ;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
