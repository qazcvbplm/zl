<template>
  <div>
    <h2>跑腿订单</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <el-dropdown @command="handleCommand">
        <el-button type="primary">
          {{status}}<i class="el-icon-arrow-down el-icon--right"></i>
        </el-button>
        <el-dropdown-menu slot="dropdown">
           <el-dropdown-item command="全部状态">全部状态</el-dropdown-item>
          <el-dropdown-item command="待付款">待付款</el-dropdown-item>
          <el-dropdown-item command="待接手">待接手</el-dropdown-item>
          <el-dropdown-item command="商家已接手">商家已接手</el-dropdown-item>
          <el-dropdown-item command="配送员已接手">配送员已接手</el-dropdown-item>
          <el-dropdown-item command="已完成">已完成</el-dropdown-item>
          <el-dropdown-item command="已取消">已取消</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column fixed prop="id" label="ID" width="60"></el-table-column>
      <el-table-column prop="status" label="状态" width="100">
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.style"
            disable-transitions
          >{{scope.row.status}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column fixed prop="createTime" label="下单时间"></el-table-column>
      <el-table-column fixed prop="totalPrice" label="订单总额"></el-table-column>
      <el-table-column fixed prop="content" label="跑腿详情"></el-table-column>
      <el-table-column fixed prop="remark" label="跑腿备注"></el-table-column>
      <el-table-column fixed prop="addressName" label="用户姓名"></el-table-column>
      <el-table-column fixed prop="addressPhone" label="用户电话" width="120"></el-table-column>
      <el-table-column fixed prop="addressDetail" label="用户地址"></el-table-column>
      <el-table-column fixed prop="senders" label="配送员" width="70"></el-table-column>
      <!-- <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id)">强制取消</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">强制完成</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column> -->
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      status: '全部状态',
      data: [],
      total: 0,
      searchList: [
      { key: "name", value: "", label: "请输入用户手机号" },
      ],
      getDataListquery: {
        page: 1,
        size: 10,
        schoolId: sessionStorage.getItem("schoolId")
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询商铺
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/runorders/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            for (var i = 0; i < res.data.params.list.length; i++) {
                res.data.params.list[i].senders = []
                if (res.data.params.list[i].payment == '') {
                    res.data.params.list[i].payTime = '未付款';
                }
                if(res.data.params.list[i].senderName){
                  res.data.params.list[i].senders.push(res.data.params.list[i].senderName + ','+ res.data.params.list[i].senderPhone)
                }else{
                  res.data.params.list[i].senders = '配送员未接手'
                }
                switch (res.data.params.list[i].status) {
                case "待付款":
                    res.data.params.list[i].style = 'success';
                    break;
                case "待接手":
                    res.data.params.list[i].style = 'danger';
                    break;
                case "商家已接手":
                    res.data.params.list[i].style = '';
                    break;
                case "配送员已接手":
                    res.data.params.list[i].style = '';
                    break;
                case "已完成":
                    res.data.params.list[i].style = 'warning';
                    break;
                case "已取消":
                    res.data.params.list[i].style = 'info';
                    break;
                }
            }
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //搜索
    search() {
      if (this.searchList[0].value != "" && this.status != '全部状态') {
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
          addressPhone: this.searchList[0].value,
          status: this.status
        }
        this.getDataList();
      }else if(this.searchList[0].value == "" && this.status != '全部状态'){
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
          status: this.status
        }
        this.getDataList();
      }else if(this.searchList[0].value != "" && this.status == '全部状态'){
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
          addressPhone: this.searchList[0].value,
        }
        this.getDataList();
      }else if(this.searchList[0].value == "" && this.status == '全部状态'){
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
        }
        this.getDataList();
      }
    },
    //清除搜索内容
    clear() {
      for (var i in this.searchList) {
        this.searchList[i].value = "";
      }
    },

    handleCommand(command) {
      this.status = command
      if (this.searchList[0].value != "" && this.status != '全部状态') {
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
          addressPhone: this.searchList[0].value,
          status: this.status
        }
        this.getDataList();
      }else if(this.searchList[0].value == "" && this.status != '全部状态'){
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
          status: this.status
        }
        this.getDataList();
      }else if(this.searchList[0].value != "" && this.status == '全部状态'){
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
          addressPhone: this.searchList[0].value,
        }
        this.getDataList();
      }else if(this.searchList[0].value == "" && this.status == '全部状态'){
        this.getDataListquery = {
          page: 1,
          size: 10,
          schoolId: sessionStorage.getItem("schoolId"),
        }
        this.getDataList();
      }
    },

    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
