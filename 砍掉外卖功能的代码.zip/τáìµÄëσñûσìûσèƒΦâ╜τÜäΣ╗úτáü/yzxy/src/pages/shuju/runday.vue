<template>
  <div>
    <h2>每日跑腿统计</h2>
    <h6 style="color:#999">（每日凌晨统计）</h6>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="day" label="对账日期"></el-table-column>
      <el-table-column prop="parentGet" label="超级后台所得"></el-table-column>
      <el-table-column prop="selfGet" label="负责人所得"></el-table-column>
      <el-table-column prop="totalCount" label="总订单数"></el-table-column>
      <el-table-column prop="totalPrice" label="总营业额"></el-table-column>
      <el-table-column prop="wxPayGet" label="微信支付"></el-table-column>
      <el-table-column prop="bellPayGet" label="余额支付"></el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [
        { key: "phone", value: "", label: "输入信息" }
      ],
      getDataListquery: {
        page: 1,
        size: 10,
        selfId: sessionStorage.getItem("schoolId"),
        type: '学校跑腿日志'
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询兑换的订单
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/daylogtakeout/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    },
    filterStatus(value, row) {
      return row.is_show == value;
      console.log(111)
    }
  }
};
</script>