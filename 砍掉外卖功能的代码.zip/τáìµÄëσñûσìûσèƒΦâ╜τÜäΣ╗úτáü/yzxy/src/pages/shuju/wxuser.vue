<template>
  <div>
    <h2>微信用户</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>
    <el-table
      :data="data"
      style="width: 100%;margin-top:15px"
    >
      <el-table-column prop="openId" label="ID"></el-table-column>
      <el-table-column label="头像">
        <template slot-scope="scope">
          <Avatar shape="square" :src="scope.row.avatarUrl"/>
        </template>
      </el-table-column>
      <el-table-column prop="nickName" label="昵称"></el-table-column>
      <el-table-column prop="phone" label="电话"></el-table-column>
      <el-table-column prop="province" label="省份"></el-table-column>
      <el-table-column prop="city" label="城市"></el-table-column>
      <el-table-column prop="gender" label="性别"></el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page 
      :total="total" 
      :current="getDataListquery.page" 
      :page-size="getDataListquery.size" 
      show-sizer 
      show-total
      @on-change="changePage"
      @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>

<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [
        { key: "nickName", value: "", label: "输入用户昵称" },
        { key: "phone", value: "", label: "输入用户电话" },
      ],
      getDataListquery: {
        page: 1,
        size: 10,
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询用户
    getDataList() {
      if(sessionStorage.getItem("schoolId")){
        this.getDataListquery.schoolId = sessionStorage.getItem("schoolId")
      }else if(sessionStorage.getItem("surperId")){
        this.getDataListquery.appId = sessionStorage.getItem("surperId")
      }
      this.$http
        .post(this.com.NODE_API + "/ops/user/find",this.getDataListquery, 
        {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
              // for (var i = 0; i < res.data.params.list.length; i++) {
              //   res.data.params.list[i].nickName = decodeURI(res.data.params.list[i].nickName);
              // }
            that.data = res.data.params.list;
            that.total = res.data.params.total[0].total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //搜索
    search() {
      if (this.searchList[0].value != '' && this.searchList[1].value != ''){
        this.getDataListquery = {
          page: 1,
          size: 10,
          nickName: this.searchList[0].value,
          phone : this.searchList[1].value,
        };
      }else if (this.searchList[0].value != '' && this.searchList[1].value == ''){
        this.getDataListquery = {
          page: 1,
          size: 10,
          nickName: this.searchList[0].value,
        };
      }else if(this.searchList[0].value == '' && this.searchList[1].value != ''){
        this.getDataListquery = {
          page: 1,
          size: 10,
          phone : this.searchList[1].value,
        };
      }
      this.$http
        .post(this.com.NODE_API + "/ops/user/find", this.getDataListquery, 
        {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total[0].total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //清除搜索内容
    clear() {
      this.getDataListquery = {
        page: 1,
        size: 10
      };
      for (var i in this.searchList) {
        this.searchList[i].value = "";
      }
      this.getDataList();
    },

    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
