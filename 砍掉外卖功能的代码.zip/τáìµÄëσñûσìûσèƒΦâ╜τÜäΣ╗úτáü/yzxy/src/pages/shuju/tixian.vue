<template>
  <div>
    <h2>提现统计</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>
    <el-table
      :data="data"
      style="width: 100%;margin-top:15px"
    >
      <el-table-column prop="txName" label="提现者"></el-table-column>
      <el-table-column prop="type" label="类型"></el-table-column>
      <el-table-column prop="amount" label="数额"></el-table-column>
      <el-table-column prop="createTime" label="提现时间"></el-table-column>
      <el-table-column prop="isTx" label="状态">
        <template slot-scope="scope" v-if="scope.row.type != '代理提现'">
          <el-tag
            :type="scope.row.style"
            disable-transitions
          >{{scope.row.text}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope" v-if="scope.row.isTx == 0 && scope.row.type != '代理提现'">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id)">审核通过</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(2,scope.row.id)">审核失败</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page 
      :total="total" 
      :current="getDataListquery.page" 
      :page-size="getDataListquery.size" 
      show-sizer 
      show-total
      @on-change="changePage"
      @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>

<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [
        { key: "nickName", value: "", label: "输入名称" },
      ],
      getDataListquery: {
        page: 1,
        size: 10,
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询用户
    getDataList() {
      if(sessionStorage.getItem("schoolId")){
        this.getDataListquery.schoolId = sessionStorage.getItem("schoolId")
      }else if(sessionStorage.getItem("surperId")){
        this.getDataListquery.appId = sessionStorage.getItem("surperId")
      }
      this.$http
        .post(this.com.NODE_API + "/ops/txlog/find",this.getDataListquery, 
        {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            for(var i in res.data.params.list){
              let date = new Date(res.data.params.list[i].createTime);
              var y = date.getFullYear();
              var m = date.getMonth() + 1;
              m = m < 10 ? ('0'+ m) : m;
              var d = date.getDate();
              d = d < 10 ? ('0'+ d) : d;
              var h = date.getHours();
              h = h < 10 ? ('0'+ h) : h;
              var minute = date.getMinutes();
              minute = minute < 10 ? ('0'+ minute) : minute;
              var second = date.getSeconds();
              second = second < 10 ? ('0'+ second) : second;
              res.data.params.list[i].createTime = y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;   
              switch (res.data.params.list[i].isTx) {
              case 0:
                  res.data.params.list[i].style = '';
                  res.data.params.list[i].text = '等待审核'
                break;
              case 1:
                  res.data.params.list[i].style = 'success';
                  res.data.params.list[i].text = '审核通过'
                break;
              case 2:
                  res.data.params.list[i].style = 'danger';
                  res.data.params.list[i].text = '审核失败'
                break;
              }             
            }
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },

    update(e,id) {
        var content = e == 1? '是否确认审核通过，通过后将直接打款给对方' :'是否确认审核失败，失败后需对方重新提交'
        this.$confirm(
          content,
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + '/ops/txlog/txaudit',
              { txId: id,status:e},
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '状态变更成功'
                });                
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
    },

    //清除搜索内容
    clear() {
      this.getDataListquery = {
        page: 1,
        size: 10
      };
      for (var i in this.searchList) {
        this.searchList[i].value = "";
      }
      this.getDataList();
    },

    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
