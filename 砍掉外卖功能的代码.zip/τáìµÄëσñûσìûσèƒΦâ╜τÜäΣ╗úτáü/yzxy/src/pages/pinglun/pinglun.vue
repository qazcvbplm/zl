<template>
  <div>
    <h2>用户评论列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="id" label="ID" width="100"></el-table-column>
      <el-table-column prop="createTime" label="评论时间"></el-table-column>
      <el-table-column prop="orderid" label="订单编号"></el-table-column>
      <el-table-column prop="core" label="评论分数"></el-table-column>
      <el-table-column prop="content" label="用户评论"></el-table-column>
      <el-table-column prop="replyContent" label="商家回复"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.orderid,scope.row.id)">查看订单</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.orderid,scope.row.id)">删除评论</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
    <el-dialog title="订单信息" :visible.sync="newDialog" width="70%" center>
        <el-table :data="orders" style="width: 100%">
            <el-table-column prop="typ" label="订单类型"></el-table-column>
            <el-table-column prop="waterNumber" label="流水号"></el-table-column>
            <el-table-column prop="users" label="用户信息"></el-table-column>
            <el-table-column prop="senders" label="配送员信息"></el-table-column>
            <el-table-column prop="shops" label="商家信息"></el-table-column>
        </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button @click="newDialog = false">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      orders:[],
      total: 0,
      getDataListquery: {
        page: 1,
        size: 10,
        schoolId: sessionStorage.getItem("schoolId"),
        isDelete: 0
      },
      newDialog:false
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询兑换的订单
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/evaluate/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    
    update(e, orderid, id) {
      if (e == 0) {
          this.$http
            .post(
              this.com.NODE_API + "/ops/orders/find",
              { id: orderid,},
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                    if(res.data.params.list[0].senderName){
                        res.data.params.list[0].senders = res.data.params.list[0].senderName + ','+ res.data.params.list[0].senderPhone
                    }else{
                        res.data.params.list[0].senders = "自取订单无配送员信息"
                    }   
                    res.data.params.list[0].users = res.data.params.list[0].addressName + ','+ res.data.params.list[0].addressPhone
                    res.data.params.list[0].shops = res.data.params.list[0].shopName + ','+ res.data.params.list[0].shopPhone
                    that.orders = res.data.params.list;
                    this.newDialog = true;
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
      }else{
        this.$confirm(
          "确定删除此评论？",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + '/ops/evaluate/update',
              { id: id, isDelete: 1},
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '删除成功'
                }); 
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      }
    },
    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    },
  }
};
</script>