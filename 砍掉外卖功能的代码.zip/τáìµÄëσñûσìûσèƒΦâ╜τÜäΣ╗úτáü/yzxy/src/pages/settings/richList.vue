<template>
  <div>
    <div class="flexr-start item-center">
      <h2 class="margin-left-shi">图文列表</h2>
    </div>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="flexr-between">
      <ButtonGroup>
        <Button @click="navTo('/richSetting')">添加图文</Button>
      </ButtonGroup>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="id" label="ID"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">删除</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id)">编辑</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //跳转添加楼栋
    navTo(path) {
      this.$router.push({ path: path });
    },
    //查询总分类
    getDataList() {
      this.$http
        .post(
          this.com.NODE_API + "/ops/rich/text/find",
          { parentId: sessionStorage.getItem("schoolId") },
          {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          }
        )
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.msg;
            that.total = res.data.params.msg.length;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },

    update(e, id) {
      if (e == 0) {
        this.$confirm(
          "此操作将永久删除该数据, 是否继续? 若误删请联系开发人员",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/rich/text/delete",
              { id: id },
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: "删除成功"
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      } else if (e == 1) {
        var querydata = "";
        for (var i = 0; i < this.data.length; i++) {
          if (this.data[i].id == id) {
            querydata = this.data[i];
          }
        }
        this.$router.push({ path: "/richSetting", query: querydata });
      }
    },

  }
};
</script>