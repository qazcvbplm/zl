<template>
  <div>
    <div class="flexr-start item-center">
      <el-button @click="navTo('/floorlList')" size="mini" icon="el-icon-arrow-left" circle></el-button>
      <h2 class="margin-left-shi">保存楼栋</h2>
    </div>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="flexc-start item-center">
      <iframe
        src="http://api.map.baidu.com/lbsapi/getpoint/index.html"
        frameborder="0"
        style="height:600px;width:750px"
      ></iframe>
      <div style="padding-top:20px;width:670px">
        <Form :model="wxamsg" :label-width="80">
          <FormItem label="楼栋名称">
            <Input v-model="wxamsg.name" placeholder="请输入楼栋名称" style="width:400px"/>
          </FormItem>
          <FormItem label="楼栋经度">
            <Input v-model="wxamsg.lng" placeholder="将顶部地图复制的经度填入（左边部分）" style="width:400px"/>
          </FormItem>
          <FormItem label="楼栋纬度">
            <Input v-model="wxamsg.lat" placeholder="将顶部地图复制的纬度填入（右边部分）" style="width:400px"/>
          </FormItem>
          <FormItem>
            <Button type="primary" :loading="loading" @click="submitData()">保存提交</Button>
          </FormItem>
        </Form>
      </div>
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
export default {
  data() {
    return {
      loading: false,
      wxamsg: {
        name: "",
        lat: "",
        lng: "",
        ableTop: 0
      }
    };
  },
  mounted() {
    var that = this
    if(this.$route.query.id){
        this.wxamsg = {
        id:this.$route.query.id,
        name: this.$route.query.name,
        lat: this.$route.query.lat,
        lng: this.$route.query.lng,
        ableTop: 0
      }
    }else{
        this.wxamsg = {
        name: "",
        lat: "",
        lng: "",
        ableTop: 0
      }
    }
  },
  methods: {
    navTo(path){
       this.$router.go(-1)
    },
    //添加楼栋
    submitData() {
      var that = this;
      this.loading = true;
      if(this.$route.query.id){
        this.$http
          .post(this.com.NODE_API + "/ops/floor/update", this.wxamsg, {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
          .then(res => {
            if (res.data.code) {
              that.$message({
                showClose: true,
                type: "success",
                message: '更新成功'
              });
              this.$router.go(-1)
            } else {
              that.$message({
                showClose: true,
                type: "error",
                message: res.data.msg
              });
            }
            that.loading = false;
          });
      }else{
        this.$http
          .post(this.com.NODE_API + "/ops/floor/add", this.wxamsg, {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
          .then(res => {
            if (res.data.code) {
              that.$message({
                showClose: true,
                type: "success",
                message: '添加成功'
              });
              this.$router.go(-1)
            } else {
              that.$message({
                showClose: true,
                type: "error",
                message: res.data.msg
              });
            }
            that.loading = false;
          });
      }
    }
  }
};
</script>
