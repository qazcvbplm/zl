<template>
  <div>
    <h2>学校列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>
    <div class="flexr-between">
      <ButtonGroup>
        <Button @click="navTo('/addSchool')">新增学校</Button>
      </ButtonGroup>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px" >
      <el-table-column fixed prop="id" label="ID"></el-table-column>
      <el-table-column fixed prop="name" label="学校名称"></el-table-column>
      <el-table-column fixed prop="phone" label="负责人电话"></el-table-column>
      <el-table-column fixed prop="loginName" label="登录账号"></el-table-column>
      <el-table-column fixed prop="wxAppId" label="小程序Id"></el-table-column>
      <el-table-column fixed prop="rate" label="对该校抽成"></el-table-column>
      <el-table-column fixed prop="money" label="负责人可提现"></el-table-column>
      <el-table-column fixed prop="senderMoney" label="配送员可提现"></el-table-column>
      <el-table-column fixed prop="senderAllTx" label="配送员累积提现"></el-table-column>
      <el-table-column fixed prop="userCharge" label="用户累积充值"></el-table-column>
      <el-table-column fixed prop="userChargeSend" label="用户累积赠送"></el-table-column>
      <el-table-column fixed prop="userBellAll" label="用户剩余额度"></el-table-column>
      <el-table-column fixed prop="createTime" label="创建时间"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">删除</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id)">编辑</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
       <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [
        { key: "wxAppId", value: "", label: "输入小程序ID" },
        { key: "name", value: "", label: "输入学校名称" }
      ],
      getDataListquery: {
        page: 1,
        size: 10000,
        orderBy: "sort desc",
        queryType: "school",
        appId: sessionStorage.getItem("surperId")
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询学校
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/school/find", this.getDataListquery, {
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            for(var i in res.data.params.list){
              res.data.params.list[i].createTime = res.data.params.list[i].createTime.substring(0, 10);
            }
            that.data = res.data.params.list;
            that.total = res.data.params.list.length;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //跳转添加学校
    navTo(path) {
      this.$router.push({ path: path });
    },
    //搜索
    search() {
      if (this.searchList[0].value != '' && this.searchList[1].value != ''){
        this.getDataListquery = {
          page: 1,
          size: 10000,
          orderBy: "sort desc",
          queryType: "school",
          wxAppId: this.searchList[0].value,
          name: this.searchList[1].value,
          appId: sessionStorage.getItem("surperId")
        };
      }else if (this.searchList[0].value != '' && this.searchList[1].value == ''){
        this.getDataListquery = {
          page: 1,
          size: 10000,
          orderBy: "sort desc",
          queryType: "school",
          wxAppId: this.searchList[0].value,
          appId: sessionStorage.getItem("surperId")
        };
      }else if(this.searchList[0].value == '' && this.searchList[1].value != ''){
        this.getDataListquery = {
          page: 1,
          size: 10000,
          orderBy: "sort desc",
          queryType: "school",
          name: this.searchList[1].value,
          appId: sessionStorage.getItem("surperId")
        };
      }
      this.$http
        .post(
          this.com.NODE_API + "/ops/school/find",
          this.getDataListquery,
          { emulateJSON: true }
        )
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //清除搜索内容
    clear() {
      this.getDataListquery = {
        page: 1,
        size: 10000,
        orderBy: "sort desc",
        queryType: "school",
        appId: sessionStorage.getItem("surperId")
      };
      for (var i in this.searchList) {
        this.searchList[i].value = "";
      }
      this.getDataList();
    },
    update(e, id) {
      if (e == 0) {
        this.$confirm(
          "此操作将永久删除该数据, 是否继续? 若误删请联系开发人员",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/school/update",
              { id: id, isDelete: 1 },
              {headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '删除成功'
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      } else if (e == 1) {
        var querydata = "";
        for (var i = 0; i < this.data.length; i++) {
          if (this.data[i].id == id) {
            querydata = this.data[i];
          }
        }
        this.$router.push({ path: "/addSchool", query: querydata });
      }
    },

    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
