<template>
  <div>
    <h2>楼栋列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>
    <div class="flexr-between">
      <ButtonGroup>
        <Button @click="navTo('/addFloor')">新增楼栋</Button>
      </ButtonGroup>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column fixed prop="id" label="ID" width="120"></el-table-column>
      <el-table-column fixed prop="name" label="楼栋名称"></el-table-column>
      <el-table-column fixed prop="lng" label="楼栋经度"></el-table-column>
      <el-table-column fixed prop="lat" label="楼栋纬度"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="zhiding(scope.row.id)">置顶</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">删除</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id)">编辑</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="tongji(scope.row.id)">数据统计</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="数据统计" :visible.sync="newDialog4" width="50%" center>
      <div class="flexr-between item-center border-bottom">
        <div class="block">
          <span class="demonstration">设置开始时间</span>
          <el-date-picker
            v-model="firsttime"
            type="datetime"
            placeholder="选择日期时间"
            default-time="00:00:01">
          </el-date-picker>
        </div>
        <div class="block">
          <span class="demonstration">设置结束时间</span>
          <el-date-picker
            v-model="lasttime"
            type="datetime"
            placeholder="选择日期时间"
            default-time="23:59:59">
          </el-date-picker>
        </div>
        <el-button type="primary" @click="fidexiangxishuju()">查询</el-button>
      </div>
      <el-table
        :data="xiangxishuju"
        style="width: 100%;margin-top:10px"
        class="flexr-bentwee item-center margin-top-ershi"
      >
        <el-table-column prop="allOrders" label="所有订单"></el-table-column>
        <el-table-column prop="allOrdersRunning" label="跑腿订单"></el-table-column>
        <el-table-column prop="allOrdersGetSelf" label="自取订单"></el-table-column>
        <el-table-column prop="allOrdersTakeOut" label="外卖订单"></el-table-column>
        <el-table-column prop="allOrdersEatHere" label="堂食订单"></el-table-column>
        <el-table-column prop="ordersAllMoney" label="营业额"></el-table-column>
      </el-table>
    </el-dialog>


    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      firsttime: '',
      lasttime: '',
      buildId: '',
      newDialog4: false,
      data: [],
      total: 0,
      searchList: [{ key: "name", value: "", label: "输入楼栋名称" }],
      getDataListquery: {
        page: 1,
        size: 10
      },
      xiangxishuju: [{
        allOrdersRunning: 0,
        allOrdersGetSelf: 0,
        allOrders: 0,
        allOrdersTakeOut: 0,
        allOrdersEatHere: 0,
        ordersAllMoney: 0,
      }],
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询楼栋
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/floor/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //跳转添加楼栋
    navTo(path) {
      this.$router.push({ path: path });
    },
    //搜索
    search() {
      if (this.searchList[0].value != "") {
        this.getDataListquery = {
          page: 1,
          size: 10,
          name: this.searchList[0].value
        };
      }
      this.$http
        .post(this.com.NODE_API + "/ops/floor/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total[0].total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //清除搜索内容
    clear() {
      this.getDataListquery = {
        page: 1,
        size: 10
      };
      for (var i in this.searchList) {
        this.searchList[i].value = "";
      }
      this.getDataList();
    },

    zhiding(id) {
      var  date1 =new Date();
      this.$http
        .post(
          this.com.NODE_API + "/ops/floor/update",
          { id: id, sort: (Date.parse(date1)) },
          {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          }
        )
        .then(res => {
          if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: "置顶成功"
            });
            this.getDataList();
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    update(e, id) {
      if (e == 0) {
        this.$confirm(
          "此操作将永久删除该数据, 是否继续? 若误删请联系开发人员",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/floor/update",
              { id: id, isDelete: 1 },
              {headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '删除成功'
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      } else if (e == 1) {
        var querydata = "";
        for (var i = 0; i < this.data.length; i++) {
          if (this.data[i].id == id) {
            querydata = this.data[i];
          }
        }
        this.$router.push({ path: "/addFloor", query: querydata });
      }
    },

    tongji (id) {
      this.firsttime = '';
      this.lasttime = '';
      this.xiangxishuju = [{
        allOrdersRunning: 0,
        allOrdersGetSelf: 0,
        allOrders: 0,
        allOrdersTakeOut: 0,
        allOrdersEatHere: 0,
        ordersAllMoney: 0,
      }],
      this.newDialog4 = true;
      this.buildId = id
    },
    
        fidexiangxishuju () {
      let date = new Date(this.firsttime);  
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0'+ m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0'+ d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0'+ h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0'+ minute) : minute;
      var second = date.getSeconds();
      second = second < 10 ? ('0'+ second) : second;
      let date_value = y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;  
      let date2 = new Date(this.lasttime); 
      var y2 = date2.getFullYear();
      var m2 = date2.getMonth() + 1;
      m2 = m2 < 10 ? ('0'+ m2) : m2;
      var d2 = date2.getDate();
      d2 = d2 < 10 ? ('0'+ d2) : d2;
      var h2 = date2.getHours();
      h2 = h2 < 10 ? ('0'+ h2) : h2;
      var minute2 = date2.getMinutes();
      minute2 = minute2 < 10 ? ('0'+ minute2) : minute2;
      var second2 = date2.getSeconds();
      second2 = second2 < 10 ? ('0'+ second2) : second2; 
      let date_value2= y2 + '-' + m2 + '-' + d2 + ' ' + h2 + ':' + minute2 + ':' + second2; 
      this.$http
        .post(this.com.NODE_API + "/ops/orders/findOrdersByFloor", {buildId: this.buildId,beginTime:date_value,endTime:date_value2}, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            
            this.xiangxishuju[0].allOrdersRunning = res.data.params.allOrdersRunning;
            this.xiangxishuju[0].allOrdersGetSelf= res.data.params.allOrdersGetSelf;
            this.xiangxishuju[0].allOrders= res.data.params.allOrders;
            this.xiangxishuju[0].allOrdersTakeOut= res.data.params.allOrdersTakeOut;
            this.xiangxishuju[0].allOrdersEatHere= res.data.params.allOrdersEatHere;
            this.xiangxishuju[0].ordersAllMoney= res.data.params.ordersAllMoney;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },

    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
