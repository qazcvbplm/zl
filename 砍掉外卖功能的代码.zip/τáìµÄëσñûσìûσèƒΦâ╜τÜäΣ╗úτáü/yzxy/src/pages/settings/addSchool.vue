<template>
    <div>
        <div class="flexr-start item-center">
          <el-button @click="navTo('/schoolList')" size="mini" icon="el-icon-arrow-left" circle ></el-button>
          <h2 class="margin-left-shi">保存学校</h2>
        </div>
        <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
        <Form :model="wxamsg" :label-width="200" style="margin-top:20px;width:800px">
            <FormItem label="学校名称">
                <Input v-model="wxamsg.name" placeholder="请输入学校名称"></Input>
            </FormItem>
            <FormItem label="负责人电话">
                <Input v-model="wxamsg.phone" placeholder="请输入负责人电话"></Input>
            </FormItem>
            <FormItem label="该校登录账号">
                <Input v-model="wxamsg.loginName" placeholder="请输入后台登录账号"></Input>
            </FormItem>
            <FormItem label="该校登录密码">
                <Input v-model="wxamsg.loginPassWord" placeholder="请输入后台登录密码"></Input>
            </FormItem>
           <FormItem label="小程序Appid">
                <Input v-model="wxamsg.wxAppId" placeholder="请输入小程序Appid"></Input>
            </FormItem>
           <FormItem label="小程序密钥">
                <Input v-model="wxamsg.wxSecret" placeholder="请输入小程序密钥"></Input>
            </FormItem>
           <FormItem label="微信支付商户号">
                <Input v-model="wxamsg.mchId" placeholder="请输入商户号"></Input>
            </FormItem>
           <FormItem label="微信支付密钥">
                <Input v-model="wxamsg.wxPayId" placeholder="请输入支付密钥"></Input>
            </FormItem>
           <FormItem label="对学校抽成">
                <Input v-model="wxamsg.rate" placeholder="请输入抽成（最低0.006）"></Input>
            </FormItem>
            <div class="flexr-start">
              <FormItem label="基础配送距离">
                    <Input v-model="wxamsg.sendMaxDistance" placeholder="基础配送距离(米)"></Input>
              </FormItem>
              <FormItem label="超出多少米">
                    <Input v-model="wxamsg.sendPerOut" placeholder="超出基础配送距离多少（米）"></Input>
              </FormItem>
              <FormItem label="增加多少额外配送费">
                    <Input v-model="wxamsg.sendPerMoney" placeholder="增加多少配送费用（元）"></Input>
              </FormItem>
            </div>
           <FormItem label="配送员选楼下送达返还用户金额">
                <Input v-model="wxamsg.topDown" placeholder="返还至用户钱包余额"></Input>
            </FormItem>
            <FormItem label="是否开启外卖功能">
              <el-switch v-model="wxamsg.enableTakeout"></el-switch>
            </FormItem>
            <el-upload
              class="upload-demo"
              action="http://www.chuyinkeji.cn:11000/ops/cert/up"
              accept=".p12"
              :headers = "headers"
              :on-error="handledie"
              :on-success="handleSuccess"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              :limit="1"
              :on-exceed="handleExceed"
              :file-list="fileList">
              <el-button size="small" type="primary">点击上传</el-button>
              <div slot="tip" class="el-upload__tip">上传微信证书.p12文件</div>
            </el-upload>
            <FormItem>
                <Button type="primary" :loading="loading" @click="submitData()">保存提交</Button>
            </FormItem>
        </Form>
    </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
export default {
  data() {
    return {
                headers: {
                    'token': sessionStorage.getItem("token")
                },
      loading: false,
      fileList: [],
      wxamsg: {
        appId: sessionStorage.getItem("surperId"),
        name: "",
        phone: "",
        loginName: "",
        loginPassWord: "",
        wxAppId: "",
        wxSecret: "",
        mchId: "",
        wxPayId: "",
        rate: "",
        sendMaxDistance: "",
        sendPerOut: "",
        sendPerMoney: "",
        topDown:"",
        enableTakeout: false,
        certPath: ""
      }
    };
  },
  mounted() {
     var that = this;
    if(this.$route.query.id){
        this.wxamsg = {
        enableTakeout: this.$route.query.enableTakeout == 1 ? true : false,
        appId: sessionStorage.getItem("surperId"),
        id:this.$route.query.id,
        name: this.$route.query.name,
        phone:this.$route.query.phone,
        loginName: this.$route.query.loginName,
        loginPassWord: this.$route.query.loginPassWord,
        wxAppId: this.$route.query.wxAppId,
        wxSecret: this.$route.query.wxSecret,
        mchId: this.$route.query.mchId,
        wxPayId: this.$route.query.wxPayId,
        rate: this.$route.query.rate,
        sendMaxDistance: this.$route.query.sendMaxDistance,
        sendPerOut: this.$route.query.sendPerOut,
        sendPerMoney: this.$route.query.sendPerMoney,
        topDown: this.$route.query.topDown,
        certPath: this.$route.query.certPath,
        pageLayout: this.$route.query.pageLayout,
        sendPerMoney: this.$route.query.sendPerMoney,
        topDown: this.$route.query.topDown,
        certPath: this.$route.query.certPath,
        pageLayout: this.$route.query.pageLayout,
        smallMinAmount: this.$route.query.smallMinAmount,
        middleMinAmount: this.$route.query.middleMinAmount,
        largeMinAmount: this.$route.query.largeMinAmount,
        extraLargeMinAmount: this.$route.query.extraLargeMinAmount,
      }
    }else{
        this.wxamsg = {
        appId: sessionStorage.getItem("surperId"),
        name: "",
        phone: '',
        loginName: "",
        loginPassWord: "",
        wxAppId: "",
        wxSecret: "",
        mchId: "",
        wxPayId: "",
        rate: "",
        sendMaxDistance: "",
        sendPerOut: "",
        sendPerMoney: "",
        topDown:"",
        enableTakeout: false,
        certPath: ""
      }
    }
  },
  methods: {
    navTo(path){
       this.$router.go(-1)
    },

      handledie(res, file){
        this.$message.warning(`上传失败`);
      },
      handleSuccess(res) {
        this.wxamsg.certPath = res
        console.log(this.wxamsg.certPath)
      },
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
      },
      handleExceed(files, fileList) {
        this.$message.warning(`限制上传 1 个文件`);
      },
      beforeRemove(file, fileList) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      },
    //添加学校
    submitData() {
      var that = this;
      this.loading = true;
      this.wxamsg.enableTakeout = this.wxamsg.enableTakeout == true ? "1" : "0";
      if(this.$route.query.id){
        if(this.$route.query.loginPassWord == this.wxamsg.loginPassWord){
          delete this.wxamsg.loginPassWord
        }
        this.$http
        .post(this.com.NODE_API + "/ops/school/update", this.wxamsg,{
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
        .then(res => {
          if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: '更新成功'
            });
            this.$router.go(-1)
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
          that.loading = false;
        });
      }else{
        this.$http
        .post(this.com.NODE_API + "/ops/school/add", this.wxamsg,{
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
        .then(res => {
          if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: '添加成功'
            });
            this.$router.go(-1)
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
          that.loading = false;
        });
      }
    }
  }
};
</script>

