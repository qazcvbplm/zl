<template>
  <div>
    <h2 class="margin-left-shi">基础设置</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <Form :model="submitData" label-postion="top" class="margin-top-ershi" v-if="type == '学校负责人登陆'">
      <FormItem label="登录密码">
        <Input v-model="submitData.loginPassWord" placeholder="请输入修改后的密码"></Input>
      </FormItem>
      <div class="flexr-start">
        <FormItem label="跑腿小件最低金额">
          <Input v-model="submitData.smallMinAmount" placeholder="最低金额（元）"></Input>
        </FormItem>
        <FormItem label="跑腿中件最低金额" class="margin-left-ershi">
          <Input v-model="submitData.middleMinAmount" placeholder="最低金额（元）"></Input>
        </FormItem>
        <FormItem label="跑腿大件最低金额" class="margin-left-ershi">
          <Input v-model="submitData.largeMinAmount" placeholder="最低金额（元）"></Input>
        </FormItem>
        <FormItem label="跑腿超大件最低金额" class="margin-left-ershi">
          <Input v-model="submitData.extraLargeMinAmount" placeholder="最低金额（元）"></Input>
        </FormItem>
      </div>
      <FormItem>
        <Button type="primary" :loading="loading" @click="add()">保存提交</Button>
      </FormItem>
    </Form>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      type:sessionStorage.getItem("type"),
      passWord:'',
      loading: false,
      submitData: {
        enableTakeout:false,
        loginPassWord: "",
        sendMaxDistance: "",
        sendPerOut: "",
        sendPerMoney: "",
        topDown: '',
        extraLargeMinAmount: '',
        largeMinAmount: '',
        middleMinAmount: '',
        smallMinAmount: '',
        pageLayout: '',
        id: sessionStorage.getItem("schoolId")
      },
      wxamsg:{
        vipTakeoutDiscountFlag: false,
        vipRunDiscountFlag: false,
        vipRunDiscount: 1,
        vipTakeoutDiscount: 1,
      },
      getDataListquery: {
        page: 1,
        size: 10,
        orderBy: "sort desc",
        queryType: "school",
        id: sessionStorage.getItem("schoolId")
      },
    };
  },
  mounted() {
    that = this;
    if(sessionStorage.getItem("type") == '学校负责人登陆'){
      this.getDataList();
    }
  },
  methods: {
    //查询学校
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/school/find", this.getDataListquery, {
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            this.passWord = res.data.params.list[0].loginPassWord
            this.submitData.loginPassWord = res.data.params.list[0].loginPassWord
            this.submitData.pageLayout = res.data.params.list[0].pageLayout
            this.submitData.extraLargeMinAmount = res.data.params.list[0].extraLargeMinAmount
            this.submitData.largeMinAmount = res.data.params.list[0].largeMinAmount
            this.submitData.middleMinAmount = res.data.params.list[0].middleMinAmount
            this.submitData.smallMinAmount = res.data.params.list[0].smallMinAmount
            this.submitData.enableTakeout = res.data.params.list[0].enableTakeout  == 1 ? true : false
            this.submitData.sendMaxDistance = res.data.params.list[0].sendMaxDistance
            this.submitData.sendPerOut = res.data.params.list[0].sendPerOut
            this.submitData.sendPerMoney = res.data.params.list[0].sendPerMoney
            this.submitData.topDown = res.data.params.list[0].topDown
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    //添加商品
    add() {
      var that = this;
      this.loading = true;
      this.submitData.enableTakeout = this.submitData.enableTakeout == true ? "1" : "0";
        if(this.passWord == this.submitData.loginPassWord){
          delete this.submitData.loginPassWord
        }
      this.$http
        .post(this.com.NODE_API + "/ops/school/update", this.submitData, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.$message({
              showClose: true,
              type: "success",
              message: '更新成功'
            });
            this.$router.push({ path: "/settingAllBack" });
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
          that.loading = false;
        });
    },
  }
};
</script>