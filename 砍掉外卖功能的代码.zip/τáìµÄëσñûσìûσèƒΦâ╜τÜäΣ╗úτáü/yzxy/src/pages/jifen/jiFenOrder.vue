<template>
  <div>
    <h2>积分兑换订单列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="id" label="ID"></el-table-column>
      <el-table-column prop="createTime" label="下单时间"></el-table-column>
      <el-table-column prop="productName" label="积分商品"></el-table-column>
      <el-table-column prop="payPrice" label="所需积分"></el-table-column>
      <el-table-column prop="addressName" label="用户姓名"></el-table-column>
      <el-table-column prop="addressPhone" label="用户电话"></el-table-column>
      <el-table-column prop="addressDetail" label="用户地址"></el-table-column>
      <el-table-column
        :filters="[{text:'待发货',value:0},{text:'已发货',value:1}]"
        :filter-method="filterStatus"
        label="订单状态"
        width="120"
      >
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.status == '已发货' ? 'success' : 'danger'"
            disable-transitions
          >{{scope.row.status}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">发货</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="getDataListquery.page"
        :page-size="getDataListquery.size"
        show-sizer
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [
        { key: "name", value: "", label: "输入用户姓名" },
        { key: "phone", value: "", label: "输入用户电话" }
      ],
      getDataListquery: {
        page: 1,
        size: 10,
        appId: sessionStorage.getItem("surperId"),
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //查询兑换的订单
    getDataList() {
      this.$http
        .post(this.com.NODE_API + "/ops/source/order/find", this.getDataListquery, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },

    update(e, id) {
      if (e == 0) {
        this.$confirm(
          "请确定已发货给用户所对应的商品",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/source/order/update",
              { id: id, status: "已发货" },
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '操作成功'
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      }
    },
    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    },
    filterStatus(value, row) {
      return row.is_show == value;
    }
  }
};
</script>