<template>
  <div>
    <h2>积分商品列表</h2>
    <div style="margin-top:15px;border-bottom: 1px solid #e1e1e1;width:100%"></div>
    <div class="search-bar">
      <Input
        v-for="(item,index) in searchList"
        :key="index"
        v-model="item.value"
        :placeholder="item.label"
        class="il in"
      />
      <Button class="il" @click="clear()">清空</Button>
      <Button class="il" type="primary" @click="search()" style="width:100px">搜索</Button>
    </div>
    <div class="flexr-between">
      <ButtonGroup>
        <Button @click="navToaddJiFen('/addJiFen')">添加积分商品</Button>
      </ButtonGroup>
    </div>

    <el-table :data="data" style="width: 100%;margin-top:15px">
      <el-table-column prop="id" label="ID" width="100px"></el-table-column>
           <el-table-column  label="商品图片" >  
              <template slot-scope="scope">
                <img :src="scope.row.productImage" height="50px" width="70px" alt="">
              </template>
            </el-table-column>
      <el-table-column label="上架状态">
        <template slot-scope="scope">
          <el-tag
            :type="scope.row.isShow == 1 ? 'success' : 'danger'"
            disable-transitions
          >{{scope.row.isShow == 1 ? '开启' : '关闭'}}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="productName" label="商品名称"></el-table-column>
      <el-table-column prop="sale" label="商品销量"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-dropdown trigger="click">
            <el-button class="el-dropdown-link" type="text">
              操作
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <div style="width:100px" @click="update(0,scope.row.id)">删除</div>
              </el-dropdown-item>
              <el-dropdown-item>
                <div style="width:100px" @click="update(1,scope.row.id)">编辑</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>
    <div class="flexr-end" style="margin-top:20px">
      <Page
        :total="total"
        :current="1"
        :page-size="10"
        show-total
        @on-change="changePage"
        @on-page-size-change="changeSize"
      />
    </div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      data: [],
      total: 0,
      searchList: [{ key: "name", value: "", label: "请输入商品名称" }],
      getDataListquery: {
        page: 1,
        size: 10,
        schoolId: sessionStorage.getItem("surperId")
      },
    };
  },
  mounted() {
    that = this;
    this.getDataList();
  },
  methods: {
    //跳转添加商品
    navToaddJiFen(path) {
      this.$router.push({ path: path,});
    },
    //查询总商品
    getDataList() {
      this.$http
        .post(
          this.com.NODE_API + "/ops/source/product/find",
          this.getDataListquery,
          {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          }
        )
        .then(res => {
          if (res.data.code) {
            that.data = res.data.params.list;
            that.total = res.data.params.total;
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
    },
    update(e, id) {
      if (e == 0) {
        this.$confirm(
          "此操作将永久删除该数据, 是否继续? 若误删请联系开发人员",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }
        ).then(() => {
          this.$http
            .post(
              this.com.NODE_API + "/ops/source/product/update",
              { id: id, isDelete: 1 },
              {
                headers: { token: sessionStorage.getItem("token") },
                emulateJSON: true
              }
            )
            .then(res => {
              if (res.data.code) {
                that.$message({
                  showClose: true,
                  type: "success",
                  message: '删除成功'
                });
                this.getDataList();
              } else {
                that.$message({
                  showClose: true,
                  type: "error",
                  message: res.data.msg
                });
              }
            });
        });
      } else if (e == 1) {
        var querydata = "";
        for (var i = 0; i < this.data.length; i++) {
          if (this.data[i].id == id) {
            querydata = this.data[i];
          }
        }
        this.$router.push({ path: '/addJiFen',query: {data:querydata}});
      }
    },

    changePage(e) {
      this.getDataListquery.page = e;
      this.getDataList();
    },
    changeSize(e) {
      this.getDataListquery.size = e;
      this.getDataList();
    }
  }
};
</script>
