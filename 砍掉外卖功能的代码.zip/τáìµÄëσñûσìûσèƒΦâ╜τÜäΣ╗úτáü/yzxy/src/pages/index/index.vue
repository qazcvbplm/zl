<template>
  <div class="layout">
    <Layout>
      <Header>
        <Menu style="display:flex;justify-content:space-between;align-items:center" mode="horizontal" theme="dark" @on-select="navOnSelect2">
          <div  style="display:flex;justify-content:start;align-items:center">
            <img src="../../assets/logo.png" width="40px" alt>
            <span
              style="font-size:13px;font-weight:bold;margin-left:20px;color:#fff"
            >椰子校园管理系统（{{adminName}}）</span>
          </div>
          <div style="display:flex;justify-content:start;align-items:center"  v-if="type == '学校负责人登陆'">
            <MenuItem name="/senderList">
              <Icon type="md-bicycle"></Icon>
              <Badge :count="1000" :overflow-count="senderDai" class-name="demo-badge">配送员审核</Badge>
            </MenuItem>
            <MenuItem name="/ershouList">
              <Icon type="ios-basket" />
              <Badge :count="1000" :overflow-count="ershouDai" class-name="demo-badge">二手物品审核</Badge>
            </MenuItem>
          </div>
          <div style="display:flex;justify-content:start;align-items:center" v-if="type == '超级后台登陆'">
            <MenuItem name="/jiFenOrder">
              <Icon type="md-copy" />
              <Badge :count="1000" :overflow-count="sources" class-name="demo-badge">用户积分兑换提醒</Badge>
            </MenuItem>
          </div>
          <div style="display:flex;justify-content:start;align-items:center">
            <el-button type="text" @click="tologin" style="color:#fff">重登</el-button>
            <el-button type="text" @click="logout" style="color:#ff8484;margin-left:20px">退出</el-button>
          </div>
        </Menu>
      </Header>
      <Layout>
        <Sider hide-trigger :style="{background: '#fff'}">
          <Menu :active-name="activeName" theme="light" width="auto" :open-names="['1']" @on-select="navOnSelect">
            <Submenu name="1">
              <template slot="title">
                <Icon type="ios-cube-outline"></Icon>首页
              </template>
              <MenuItem name="/adminOverview">平台总览</MenuItem>
            </Submenu>
            <Submenu name="3" v-if="type == '学校负责人登陆'">
              <template slot="title">
                <Icon type="ios-paper-outline"></Icon>订单管理
              </template>
              <MenuItem name="/orderpt">跑腿订单</MenuItem>
            </Submenu>
            <Submenu name="4">
              <template slot="title">
                <Icon type="ios-pie-outline"></Icon>数据统计
              </template>
              <MenuItem name="/wxuser">用户列表</MenuItem>
              <MenuItem name="/tixian" v-if="type == '学校负责人登陆'">提现统计</MenuItem>
              <MenuItem name="/runday" v-if="type == '学校负责人登陆'">每日跑腿统计</MenuItem>
            </Submenu>
            <Submenu name="5" v-if="type == '超级后台登陆'">
              <template slot="title">
                <Icon type="ios-flag-outline"></Icon>学校管理
              </template>
              <MenuItem name="/schoolList">学校列表</MenuItem>
            </Submenu>
            <Submenu name="6" v-if="type == '超级后台登陆'">
              <template slot="title">
                <Icon type="ios-card-outline"></Icon>充值管理
              </template>
              <MenuItem name="/rechage">充值列表</MenuItem>
            </Submenu>
            <Submenu name="7" v-if="type == '超级后台登陆'">
              <template slot="title">
                <Icon type="ios-analytics-outline" />积分管理
              </template>
              <MenuItem name="/jiFenList">积分商品列表</MenuItem>
            </Submenu>
            <Submenu name="8" v-if="type == '学校负责人登陆'">
              <template slot="title">
                <Icon type="ios-hammer-outline"></Icon>平台管理
              </template>
              <MenuItem name="/richList" >推文列表</MenuItem>
              <MenuItem name="/sliderList" >轮播图</MenuItem>
              <MenuItem name="/noticeList">公告管理</MenuItem>
              <MenuItem name="/floorList">楼栋管理</MenuItem>
              <MenuItem name="/settingSchool">基础设置</MenuItem>
            </Submenu>
          </Menu>
        </Sider>
        <Layout :style="{padding: '24px 24px 24px'}">
          <Content :style="{padding: '24px', minHeight: '280px', background: '#fff'}"><router-view /></Content>
        </Layout>
      </Layout>
    </Layout>
    <div
      class="flexr-center item-center padding-top-ershi padding-bottom-ershi bg-white border-top"
    >科技有限公司</div>
  </div>
</template>
<style>
@import url("../../assets/css/component.css");
</style>
<script>
var that;
export default {
  data() {
    return {
      type: sessionStorage.getItem("type"),
      activeName: "/adminOverview",
      adminName: '',
      senderDai: 0,
      ershouDai: 0,
      pinglunDai: 0,
      sources:0
    };
  },
  mounted() {
    that = this;
    this.initLogin();
    if(sessionStorage.getItem("type") == '学校负责人登陆'){
      this.adminName = sessionStorage.getItem("schoolName")
    }else{
      this.adminName = sessionStorage.getItem("surperName")
    }
  },
  methods: {

    //判断是否登录
    initLogin() {
      if (sessionStorage.getItem("schoolId") && sessionStorage.getItem("type") == '学校负责人登陆') {
        this.activeName = '/adminOverview';
      this.$http
        .post(this.com.NODE_API + "/ops/sender/finddsh", {schoolId: sessionStorage.getItem("schoolId")}, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            this.senderDai = res.data.params.total;
            if(res.data.params.total != 0){
            this.$notify({
              duration: 60000,
              title: '配送员待审核提示',
              message: '有' + res.data.params.total + '条待审核的配送员信息等待处理',
              type: 'warning',
              offset: 100
            });
            }
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
      this.$http
        .post(this.com.NODE_API + "/ops/secondhand/find", {page: 1,size: 100, schoolId: sessionStorage.getItem("schoolId"),isShow: 0}, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            this.ershouDai = res.data.params.total;
            if(res.data.params.total != 0){
            this.$notify({
              duration: 60000,
              title: '二手审核提示',
              message: '有'+ res.data.params.total + '条二手物品审核，注意查看并处理',
              type: 'warning',
              offset: 100
            });
            }
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
      this.$http
        .post(this.com.NODE_API + "/ops/evaluate/find", {page: 1,size: 10,schoolId: sessionStorage.getItem("schoolId")}, {
          headers: { token: sessionStorage.getItem("token") },
          emulateJSON: true
        })
        .then(res => {
          if (res.data.code) {
            for (var i = 0; i < res.data.params.list.length; i++){
              if(res.data.params.list[i].core < 8){
                this.pinglunDai++
              }
            }
            if(this.pinglunDai != 0){
            this.$notify({
              duration: 60000,
              title: '用户差评提示',
              message: '有'+ this.pinglunDai+'条订单用户差评',
              type: 'warning',
              offset: 100
            });
            }
          } else {
            that.$message({
              showClose: true,
              type: "error",
              message: res.data.msg
            });
          }
        });
      } else if(sessionStorage.getItem("surperId") && sessionStorage.getItem("type") == '超级后台登陆'){
        this.activeName = '/adminOverview';
        this.$http
          .post(this.com.NODE_API + "/ops/source/order/find", {page: 1,size: 30,appId: sessionStorage.getItem("surperId"),}, {
            headers: { token: sessionStorage.getItem("token") },
            emulateJSON: true
          })
          .then(res => {
            if (res.data.code) {
              for (var i = 0; i < res.data.params.list.length; i++){
                if(res.data.params.list[i].status == '待发货'){
                  this.sources++
                }
              }
              if(this.sources != 0){
              this.$notify({
                duration: 60000,
                title: '用户积分兑换提示',
                message: '有'+ this.sources+'待发货的积分兑换订单等待处理',
                type: 'warning',
                offset: 100
              });
              }
            } else {
              that.$message({
                showClose: true,
                type: "error",
                message: res.data.msg
              });
            }
          });
      }else{
        this.$router.push({ path: "/login" });
      }
    },
    //退出登录
    logout() {
      if(sessionStorage.getItem("type") == '学校负责人登陆'){
      sessionStorage.removeItem("token");
      sessionStorage.removeItem("schoolId");
      sessionStorage.removeItem("schoolName");
      sessionStorage.removeItem("schoolMoney");
      sessionStorage.removeItem("senderMoney");
      sessionStorage.removeItem("loginName");
      sessionStorage.removeItem("loginPass");     
      sessionStorage.removeItem("type");
      }else{
      sessionStorage.removeItem("token");
      sessionStorage.removeItem("surperId");
      sessionStorage.removeItem("surperName");
      sessionStorage.removeItem("addSchoolList");
      sessionStorage.removeItem("loginName");
      sessionStorage.removeItem("loginPass");  
      sessionStorage.removeItem("type");
      }
      this.$router.push({ path: "/login" });
    },
    tologin(){
        this.$http
          .post(
            this.com.NODE_API + "/ops/school/login",
            { loginName: sessionStorage.getItem("loginName"), loginPass: sessionStorage.getItem("loginPass"),type: sessionStorage.getItem("type") == '学校负责人登陆'? 1:2},
            { emulateJSON: true ,}
          )
          .then(res => {
            this.loading = false;
            if (res.data.code) {
              this.$message({
                showClose: true,
                type: "success",
                message: "登录成功"
              });
                sessionStorage.setItem("token", res.data.params.token);
            } else {
              this.$message({
                showClose: true,
                type: "error",
                message: "登录失败"
              });
            }
          });
    },
    //跳转相应右边页面
    navOnSelect(e) {
      this.$router.push({ path: e });
    },
    navOnSelect2(e) {
      this.$router.push({ path: e });
    }
  }
};
</script>
