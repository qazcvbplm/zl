
const NODE_API = 'http://ops.free.idcfengye.com';
module.exports = {
    NODE_API: NODE_API
}