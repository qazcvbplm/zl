<template>
  <div id="index">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'index'
}
</script>

<style>
</style>
